//
//  ViewController.swift
//  TakeMotionDetector
//
//  Created by cat on 11/12/15.
//  Copyright © 2015 cat. All rights reserved.
//

import UIKit
import CoreMotion
import MapKit
import Foundation

class ViewController: UIViewController, SKMotionDetectorDelegate, UITableViewDelegate, UITableViewDataSource{
    var motionDetector = SKMotionDetector.getInstance()
    var currentMotionType: SKMotionType = MotionTypeNotMoving
    var startTime = [String]()
    var endTime = [String]()
    var motionType = [String]()
    var velocity = [String]()
    var tempStart : NSDate?
    var tempEnd : NSDate?
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        motionDetector.delegate = self
        SKMotionDetector.getInstance().startDetection()
    }
    
    func motionDetector(motionDetector: SKMotionDetector, motionTypeChanged motionType: SKMotionType , dist : Double, time : Double, start : NSDate, end : NSDate) {
 
        var states = [String]()
        states.insert("", atIndex: 0)
        states.insert("NotMoving", atIndex: 1)
        states.insert("Walking", atIndex: 2)
        states.insert("Running", atIndex: 3)
        states.insert("Driving", atIndex: 4)
        tempEnd = NSDate()
        let spe = (dist / time) as Double
        //print("changing", "dist = ", dist, " time = ", time, " speed = ", spe)
        SKMotionDetector.getInstance().initDistance()
        addInformation(start.description, tempEnd: end.description, tempMotion: states[motionType], tempSpeed: String(spe))
        currentMotionType = motionType
    }
    
    func speedDetector(motionDetector: SKMotionDetector, motionType: SKMotionType, dist : Double, time : Double, start : NSDate, end : NSDate) {

        var states = [String]()
        states.insert("", atIndex: 0)
        states.insert("NotMoving", atIndex: 1)
        states.insert("Walking", atIndex: 2)
        states.insert("Running", atIndex: 3)
        states.insert("Driving", atIndex: 4)
        tempEnd = NSDate()
        let spe = (dist / time) as Double
        //print("keeping", "dist = ", dist, " time = ", time, " speed = ", spe)
        changeInformation(start.description, tempEnd: end.description, tempMotion: states[motionType], tempSpeed: String(spe))
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell: tableCell! //= tableView.dequeueReusableCellWithIdentifier(identifier) as? TableViewCell
        cell = tableView.dequeueReusableCellWithIdentifier("cell") as? tableCell
        cell.start.text = self.startTime[indexPath.row]
        cell.end.text = self.endTime[indexPath.row]
        cell.motion.text = self.motionType[indexPath.row]
        cell.speed.text = self.velocity[indexPath.row]
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return startTime.count
    }
    
    func addInformation(tempStart : String, tempEnd : String, tempMotion : String, tempSpeed : String)
    {
        self.startTime.append(tempStart)
        self.endTime.append(tempEnd)
        self.motionType.append(tempMotion)
        self.velocity.append(tempSpeed)
        self.tableView.reloadData()
    }
    func changeInformation(tempStart : String, tempEnd : String, tempMotion : String, tempSpeed : String)
    {
        if !self.startTime.isEmpty
        {
            let k = self.startTime.count - 1
            self.startTime[k]  = tempStart
            //self.endTime.dropFirst()
            self.endTime[k] = tempEnd
            //self.motionType.dropFirst()
            self.motionType[k] = tempMotion
            //self.motionType.dropFirst()
            self.velocity[k] = tempSpeed
            self.tableView.reloadData()
        }
    }

}

