//
//  SOLocationManager.swift
//  TakeMotionDetector
//
//  Created by cat on 11/12/15.
//  Copyright © 2015 cat. All rights reserved.
//

import Foundation
import MapKit


let LOCATION_DID_CHANGED_NOTIFICATION = "LOCATION_DID_CHANGED_NOTIFICATION"
let LOCATION_DID_FAILED_NOTIFICATION = "LOCATION_DID_FAILED_NOTIFICATION"
let LOCATION_AUTHORIZATION_STATUS_CHANGED_NOTIFICATION = "LOCATION_AUTHORIZATION_STATUS_CHANGED_NOTIFICATION"


class SOLocationManager : NSObject, CLLocationManagerDelegate
{
    

    override init()
    {
        super.init()
        self.locationManager = CLLocationManager()
        self.locationManager!.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager!.distanceFilter = 0.3
        self.locationManager!.delegate = self
        self.locationType = 0
    }
    
    var locationManager : CLLocationManager?
    var lastLocation : CLLocation?
    var lastCoordinate : CLLocationCoordinate2D?
    var locationType : Int?
    
    class var sharedInstance: SOLocationManager {
        struct Static {
            static var onceToken: dispatch_once_t = 0
            static var instance: SOLocationManager? = nil
        }
        dispatch_once(&Static.onceToken) {
            Static.instance = SOLocationManager()
        }
        return Static.instance!
    }
    
    func start() {
        self.locationManager!.startUpdatingLocation()
        
        if self.locationType == 0
        {
            self.locationType = 2
        }
        else if self.locationType == 2
        {
            self.locationType = 0 | 2
        }
    }
    func startSignificant()
    {
        self.locationManager!.startMonitoringSignificantLocationChanges()
    
        if self.locationType == 0
        {
            self.locationType = 1
        }
        else if self.locationType == 2
        {
            self.locationType = 2 | 1
        }
    }
    
    func stop()
    {
        self.locationManager!.stopUpdatingLocation()
    
        if (self.locationType & LocationManagerTypeSignificant)
        {
            //leave only significant
            self.locationType = LocationManagerTypeSignificant;
        }
        else
        {
            self.locationType = LocationManagerTypeNone;
        }
    }
    
}