//
//  tableCell.swift
//  TakeMotionDetector
//
//  Created by cat on 11/13/15.
//  Copyright © 2015 cat. All rights reserved.
//

import Foundation
import UIKit

class tableCell : UITableViewCell{
    @IBOutlet weak var end: UILabel!
    @IBOutlet weak var start: UILabel!
    @IBOutlet weak var speed: UILabel!
    @IBOutlet weak var motion: UILabel!
}