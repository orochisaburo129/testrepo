------------ Thank you for your purchase! -----------

To get started, open the documentation folder double click the link file. 
You can also browse to http://sherdle.com/support/documentation/

----------- License -------------

For more license information, check the License.txt file inside the template's folder.

------------ Content -----------

- Your template
- Wordpress plugin (fork)
- Documentation

———————————— Upgrading —————————

V1.2
Admob Support
Bugfixes
IOS9 (Beta) & XCode 7 (Beta) Support

Upgrade instructions:
Only the config.m file and image resources (including assets) can be maintained.

V1.1
IAd Support

Upgrade instructions:
Only the config.m file and image resources (including assets) can be maintained.

V1.0
Initial release

