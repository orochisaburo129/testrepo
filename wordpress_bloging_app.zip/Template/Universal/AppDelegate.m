//
//  AppDelegate.m
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#import "AppDelegate.h"

#import <GoogleMaps/GoogleMaps.h>

#import "Config.h"

#import "CommonBanner.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    [self.window makeKeyAndVisible];
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
   [GMSServices provideAPIKey: MAPS_API_KEY];
    
    Config * obje = [[Config  alloc]init];
    
    //TODO we also do this elsewhere, perhaps a global declaration would be better
    NSIndexPath *selectedIndexPath  = [NSIndexPath indexPathForRow:0 inSection:0];
    NSArray *sectionArray = [obje config];
    NSArray *item = [[sectionArray objectAtIndex: selectedIndexPath.section] objectAtIndex:(selectedIndexPath.row + 1)];

    rearViewController = [[RearTableViewController alloc]initWithNibName:@"RearTableViewController" bundle:nil];
    
    UIViewController *viewController = [[rearViewController selectItem:item] init];
    
    frontNav = [[UINavigationController alloc]initWithRootViewController:viewController];
    
    rearNav = [[UINavigationController alloc]initWithRootViewController:rearViewController];
    
    revealController = [[SWRevealViewController alloc]initWithRearViewController:rearNav frontViewController:frontNav];
    
    [[UINavigationBar appearance] setBarTintColor:APP_THEME_COLOR];
    
    [[UINavigationBar appearance]setTintColor:[UIColor whiteColor]];
    
    [[UINavigationBar appearance]setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],NSForegroundColorAttributeName, nil]];
    
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    
    if (ADS_ON){
        [CommonBanner regitserProvider:[CommonBannerProvideriAd class]
                      withPriority:CommonBannerPriorityLow
                     requestParams:nil];
        
        if (![ADMOB_UNIT_ID isEqualToString: @""]){
        
            [CommonBanner regitserProvider:[CommonBannerProviderGAd class]
                          withPriority:CommonBannerPriorityHigh
                         requestParams:@{keyAdUnitID    : ADMOB_UNIT_ID,
                                         keyTestDevices : @[]}];
        }
    
        [CommonBanner startManaging];
    }
    
    self.window.rootViewController = revealController;

    return YES;
}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
	NSString *newToken = [deviceToken description];
	newToken = [newToken stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
	newToken = [newToken stringByReplacingOccurrencesOfString:@" " withString:@""];
    
	NSLog(@"My token is: %@", newToken);
}



- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
	NSLog(@"Failed to get token, error: %@", error);
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
