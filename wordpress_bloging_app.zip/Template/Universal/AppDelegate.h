//
//  AppDelegate.h
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//
//  INFO: In this file you can edit some of your apps main properties, like API keys
//

#import <UIKit/UIKit.h>
#import "SWRevealViewController.h"
#import "RearTableViewController.h"

#define APP_THEME_COLOR [UIColor colorWithRed:51.0f/255 green:180.0f/255 blue:227.0f/255 alpha:1.0]
#define MENU_BACKGROUND_COLOR_1 [UIColor colorWithRed:(120/255.0) green:(135/255.0) blue:(150/255.0) alpha:1.0]
#define MENU_BACKGROUND_COLOR_2 [UIColor colorWithRed:(67/255.0)  green:(89/255.0)  blue:(106/255.0)  alpha:1.0]

#define NO_CONNECTION_TEXT @"We weren't able to connect to the server. Make sure you have a working internet connection."
#define ABOUT_TEXT @"Thank you for downloading our app! \n\nIf you need any help, press the button below to visit our support."
#define ABOUT_URL @"http://yoursupporturl.com"

#define ADS_ON false
#define ADMOB_UNIT_ID @""

#define MAPS_API_KEY @"PLACEHOLDER"

#define YOUTUBE_CONTENT_KEY @"PLACEHOLDER"

#define TWITTER_API @"PLACEHOLDER"
#define TWITTER_API_SECRET @"PLACEHOLDER"
#define TWITTER_TOKEN @"PLACEHOLDER"
#define TWITTER_TOKEN_SECRET @"PLACEHOLDER"

#define FACEBOOK_ACCESS_TOKEN @"PLACEHOLDER"
#define INSTAGRAM_CLIENT_ID @"PLACEHOLDER"

@interface AppDelegate : UIResponder <UIApplicationDelegate>  {
    SWRevealViewController *revealController;
 
    RearTableViewController *rearViewController;
     
    
    UINavigationController *frontNav;
    UINavigationController *rearNav;
}

@property (strong, nonatomic) UIWindow *window;

@end
