//
//  WebViewController.m
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#import "WebViewController.h"
#import "SWRevealViewController.h"
#import "AppDelegate.h"
#import "CommonBanner.h"

@interface WebViewController ()

@end

@implementation WebViewController
@synthesize urlString;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (ADS_ON)
        self.canDisplayAds = YES;
    
    _webView = [[UIWebView alloc]init];
    
    self.title=@"Loading...";
    
    _webView.delegate=self;
    self.view = _webView;
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    btn.frame = CGRectMake(0, 0, 20, 20);
    
    [btn setImage:[UIImage imageNamed:@"reveal-icon"] forState:UIControlStateNormal];
    
    [btn addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftBarButton = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
    self.navigationItem.leftBarButtonItem = leftBarButton;
    
    UIButton *BtnBack=[UIButton buttonWithType:UIButtonTypeCustom];
    BtnBack.frame=CGRectMake(0, 0, 25, 20);
    [[BtnBack imageView] setContentMode: UIViewContentModeScaleAspectFit];
    [BtnBack setImage:[UIImage imageNamed:@"ic_menu_back.png"] forState:UIControlStateNormal];
    [BtnBack addTarget:_webView action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *BtnForward=[UIButton buttonWithType:UIButtonTypeCustom];
    BtnForward.frame=CGRectMake(40, 0, 25, 20);
    [[BtnForward imageView] setContentMode: UIViewContentModeScaleAspectFit];
    [BtnForward setImage:[UIImage imageNamed:@"ic_menu_forward.png"] forState:UIControlStateNormal];
    [BtnForward addTarget:_webView action:@selector(goForward) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIToolbar* toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(130.0f, 20.0f, 80.0f, 44.01f)];
   
    [toolbar setBarTintColor:[UIColor colorWithRed:51.0f/255 green:180.0f/255 blue:227.0f/255 alpha:1.0]];
    [toolbar setBackgroundColor:[UIColor colorWithRed:51.0f/255 green:180.0f/255 blue:227.0f/255 alpha:1.0]];
    [toolbar setTintColor:[UIColor colorWithRed:51.0f/255 green:180.0f/255 blue:227.0f/255 alpha:1.0]];
    [toolbar setShadowImage:[UIImage new] forToolbarPosition:UIBarPositionTopAttached];
    
    UIBarButtonItem *BtnForwardItem = [[UIBarButtonItem alloc]initWithCustomView:BtnForward];
    UIBarButtonItem *BtnBackItem = [[UIBarButtonItem alloc]initWithCustomView:BtnBack];
    
    UIBarButtonItem *space = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:self action:nil];
    space.width = 5;
    
    NSArray *buttons = @[BtnForwardItem, space, BtnBackItem];
    
    self.navigationItem.rightBarButtonItems = buttons;
    
}

-(void)viewWillAppear:(BOOL)animated{

    [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:urlString]]];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
}
- (void)webViewDidStartLoad:(UIWebView *)webView{
    self.title=@"Loading...";
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    self.title= _navTitle;
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    if (error.code == NSURLErrorNotConnectedToInternet){
    [[[UIAlertView alloc]initWithTitle:@"Error" message:NO_CONNECTION_TEXT delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
        
    }
    
    self.title = _navTitle;
    
}
- (void)loadRequest:(NSURLRequest *)request
{
    if ([_webView isLoading])
        [_webView stopLoading];
    [_webView loadRequest:request];
}

- (void)viewWillDisappear
{
    if ([_webView  isLoading])
        [_webView  stopLoading];
}

- (void)dealloc
{
    [_webView loadHTMLString:@"" baseURL:nil];
    [_webView stopLoading];
    [_webView removeFromSuperview];
    [_webView  setDelegate:nil];
    _webView = nil;
    self.view=nil;
}



@end
