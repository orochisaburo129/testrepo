//
//  RadioViewController.m
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#import "RadioViewController.h"
#import "SWRevealViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "AppDelegate.h"
#import <MediaPlayer/MPMediaItem.h>
#import <MediaPlayer/MPNowPlayingInfoCenter.h>
#import "UIImageView+WebCache.h"
#import "CommonBanner.h"

@interface RadioViewController ()

@end

@implementation RadioViewController
@synthesize player;
@synthesize urlString;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (ADS_ON)
        self.canDisplayAds = YES;
    
    [self.view addGestureRecognizer: self.revealViewController.panGestureRecognizer];
    [self.view addGestureRecognizer: self.revealViewController.tapGestureRecognizer];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 20, 20);
    [btn setImage:[UIImage imageNamed:@"reveal-icon"] forState:UIControlStateNormal];
    [btn addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftBarButton = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
    self.navigationItem.leftBarButtonItem = leftBarButton;
    
    _imageVieewBackground.layer.cornerRadius=8;
    
    self.title = _navTitle;
    
    [self configureAudioSession];
    
    //NSString* resourcePath =[NSString stringWithFormat:urlString];
    NSString* resourcePath =urlString;
    
    _playerItem=[AVPlayerItem alloc];
    _playerItem = [AVPlayerItem playerItemWithURL:[NSURL URLWithString:resourcePath]];
    //  player.delegate=self;
    
    player = [AVPlayer playerWithPlayerItem:_playerItem];
    player = [AVPlayer playerWithURL:[NSURL URLWithString:resourcePath]];
    player.volume = 1.0f;
    
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    [self becomeFirstResponder];
    
    // Declare block scope variables to avoid retention cycles
    // from references inside the block
    __block AVPlayer* blockPlayer = player;
    __weak UIActivityIndicatorView* indicator = _indicator;
    __weak UIImageView *playerView = _playerView;
    __block id obs;
    
    // Setup boundary time observer to trigger when audio really begins,
    // specifically after 1/3 of a second playback
    obs = [player addBoundaryTimeObserverForTimes:
           @[[NSValue valueWithCMTime:CMTimeMake(1, 3)]]
                                            queue:NULL
                                       usingBlock:^{
                                           
                                           [playerView sd_setImageWithURL:[[NSBundle mainBundle] URLForResource:@"equalizer" withExtension:@"gif"]];
                                            [indicator removeFromSuperview];
                                           // Remove the boundary time observer
                                           [blockPlayer removeTimeObserver:obs];
                                       }];
    
}
-(void)viewWillAppear:(BOOL)animated{
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [[UIApplication sharedApplication] endReceivingRemoteControlEvents];
    [self resignFirstResponder];
    
    [player pause];
}

-(void)viewDidDisappear:(BOOL)animated{
}

- (IBAction)volumeSliderChanged:(id)sender {
    player.volume = self.volumeSlider.value;
}

- (IBAction)btnplayclicked:(id)sender {
    
    _indicator.hidden = false;
    
    NSError *error;

    if (player == nil)
        
        NSLog(@"%@", [error description]);
    else
        [player play];
    
    [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = @{
          MPMediaItemPropertyTitle : @"Live Streaming",
          MPMediaItemPropertyArtist : _navTitle,
          MPNowPlayingInfoPropertyPlaybackRate:[NSNumber numberWithDouble:self.player.rate],
    };

    [_btnPlay setBackgroundImage:[UIImage imageNamed:@"ic_play_active.png"] forState:UIControlStateNormal];
    [_btnPause setBackgroundImage:[UIImage imageNamed:@"ic_pause_unactive.png"] forState:UIControlStateNormal];
    
    _playerView.hidden = false;
}

- (IBAction)btnpauseclicked:(id)sender {
    [player pause];
    
    [_btnPause setBackgroundImage:[UIImage imageNamed:@"ic_pause_active.png"] forState:UIControlStateNormal];
    [_btnPlay setBackgroundImage:[UIImage imageNamed:@"ic_play_unactive.png"] forState:UIControlStateNormal];
    
    _playerView.hidden = true;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)remoteControlReceivedWithEvent:(UIEvent *)event
{
    if(event.type == UIEventTypeRemoteControl)
    {
        switch(event.subtype)
        {
            case UIEventSubtypeRemoteControlPause:
                [player pause];
            case UIEventSubtypeRemoteControlStop:
                break;
            case UIEventSubtypeRemoteControlPlay:
                [player play];
            default:
                break;
        }
        
        [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = @{
              MPMediaItemPropertyTitle : @"Live Streaming",
              MPMediaItemPropertyArtist : _navTitle,
               MPNowPlayingInfoPropertyPlaybackRate:[NSNumber numberWithDouble:self.player.rate],
        };
    }
}

- (BOOL)canBecomeFirstResponder {
    return YES;
}


- (void)configureAudioSession {
    NSError *error;
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:&error];
    [[AVAudioSession sharedInstance] setActive:YES error:&error];
    if (error) {
        NSLog(@"Error setting category: %@", [error description]);
    }
}


@end
