//
// TwitterViewController.m
//
// Copyright (c) 2015 Sherdle. All rights reserved.
//


#import "TwitterViewController.h"
#import "AssistTableHeaderView.h"
#import "AssistTableFooterView.h"

#import "NSString+HTML.h"
#import "MWFeedParser.h"
#import "AppDelegate.h"
#import "SWRevealViewController.h"

#import "SocialFetcher.h"
#import "CommonBanner.h"
@interface TwitterViewController ()
// Private helper methods
- (void) addItemsOnTop;
- (void) addItemsOnBottom;


@end


@implementation TwitterViewController
@synthesize urlString,screenName;

- (void) viewDidLoad
{
  [super viewDidLoad];
    
    if (ADS_ON)
        self.canDisplayAds = YES;
    
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)])
        self.edgesForExtendedLayout = UIRectEdgeNone;
  
    formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateStyle:NSDateFormatterShortStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [self.tableView addGestureRecognizer: self.revealViewController.panGestureRecognizer];
    [self.tableView addGestureRecognizer: self.revealViewController.tapGestureRecognizer];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 20, 20);
    [btn setImage:[UIImage imageNamed:@"reveal-icon"] forState:UIControlStateNormal];
    [btn addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftBarButton = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
    self.navigationItem.leftBarButtonItem = leftBarButton;
    
    self.title = @"Loading...";
  
    // set the custom view for "pull to refresh". See AssistTableHeaderView.xib.
    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AssistTableHeaderView" owner:self options:nil];
    AssistTableHeaderView *headerView = (AssistTableHeaderView *)[nib objectAtIndex:0];
    self.headerView = headerView;
  
    // set the custom view for "load more". See AssistTableFooterView.xib.
    nib = [[NSBundle mainBundle] loadNibNamed:@"AssistTableFooterView" owner:self options:nil];
    AssistTableFooterView *footerView = (AssistTableFooterView *)[nib objectAtIndex:0];
    self.footerView = footerView;
  
    // add sample items
 }
-(void)viewWillAppear:(BOOL)animated{
    count=15;
    
    [[FHSTwitterEngine sharedEngine]permanentlySetConsumerKey:TWITTER_API andSecret:TWITTER_API_SECRET];
    [[FHSTwitterEngine sharedEngine]setDelegate:self];
    [[FHSTwitterEngine sharedEngine]loadAccessToken];
    
    [self willBeginLoadingMore];
    [self fetchTimeline];
    
}
-(void)fetchTimeline
{
    self.title=@"Loading...";
    
    FHSToken *token = [[FHSToken alloc] init];
    token.key = TWITTER_TOKEN;
    token.secret = TWITTER_TOKEN_SECRET;
    
    [[FHSTwitterEngine sharedEngine]setAccessToken:token];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSArray *tempArray = [[FHSTwitterEngine sharedEngine]getTimelineForUser:screenName isID:NO count:20 sinceID:nil maxID: _latestTweetID];
        
        if (self.tweetsArray == nil){
            self.tweetsArray = [[NSMutableArray alloc]init];
        }
        
        
        if (![tempArray isKindOfClass: [NSArray class]]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[[UIAlertView alloc]initWithTitle:@"Error" message:NO_CONNECTION_TEXT delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
                 
                 [self refreshCompleted];
                 [self loadMoreCompleted];
                
                 self.title= _navTitle;
            });
            
            return ;
            
        } else {
        
            if (tempArray.count == 0)
            {
                return;
            }
            for (id result in tempArray) {
                [self.tweetsArray addObject:result];
            
                long tweetID = [[result valueForKey:@"id"] longValue];
                _latestTweetID = [NSString stringWithFormat: @"%ld", tweetID - 1];
            }

            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
                [self refreshCompleted];
                [self loadMoreCompleted];
            
                self.title= _navTitle;
            });
        }
    });
    
    
}

- (void) pinHeaderView
{
  [super pinHeaderView];
  
  // do custom handling for the header view
  AssistTableHeaderView *hv = (AssistTableHeaderView *)self.headerView;
  [hv.activityIndicator startAnimating];
  hv.title.text = @"Loading...";
}

- (void) unpinHeaderView
{
  [super unpinHeaderView];
  
  // do custom handling for the header view
  [[(AssistTableHeaderView *)self.headerView activityIndicator] stopAnimating];
}

- (void) headerViewDidScroll:(BOOL)willRefreshOnRelease scrollView:(UIScrollView *)scrollView
{
    AssistTableHeaderView *hv = (AssistTableHeaderView *)self.headerView;
    if (willRefreshOnRelease)
        hv.title.text = @"Release to refresh...";
    else
        hv.title.text = @"Pull down to refresh...";
}

- (BOOL) refresh
{
  if (![super refresh])
    return NO;
  
  // Do your async call here
  // This is just a dummy data loader:
  [self performSelector:@selector(addItemsOnTop) withObject:nil afterDelay:2.0];
  // See -addItemsOnTop for more info on how to finish loading
  return YES;
}

- (void) willBeginLoadingMore
{
  AssistTableFooterView *fv = (AssistTableFooterView *)self.footerView;
  [fv.activityIndicator startAnimating];
}


- (void) loadMoreCompleted
{
  [super loadMoreCompleted];

  AssistTableFooterView *fv = (AssistTableFooterView *)self.footerView;
  [fv.activityIndicator stopAnimating];
  
  if (!self.canLoadMore) {
    // Do something if there are no more items to load
    
    // We can hide the footerView by: [self setFooterViewVisibility:NO];
    
    // Just show a textual info that there are no more items to load
    fv.infoLabel.hidden = NO;
  }
}

- (BOOL) loadMore
{
  if (![super loadMore])
    return NO;
  
  // Do your async loading here
  [self performSelector:@selector(addItemsOnBottom) withObject:nil afterDelay:2.0];
  // See -addItemsOnBottom for more info on what to do after loading more items
  
  return YES;
}

- (void) addItemsOnTop
{
    _latestTweetID = nil;
    self.tweetsArray = nil;
   [self fetchTimeline];

    
  // Call this to indicate that we have finished "refreshing".
  // This will then result in the headerView being unpinned (-unpinHeaderView will be called).
  [self refreshCompleted];
}

- (void) addItemsOnBottom
{
    [self fetchTimeline];
    
    //TODO Make working when end has reached. Do something like: when returned array lenght == nul --> canloadmore -> NO
    if (5 == 6)
        self.canLoadMore = NO; // signal that there won't be any more items to load
    else
        self.canLoadMore = YES;
  
    // Inform STableViewController that we have finished loading more items
  
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   
  return _tweetsArray.count;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"CustomCellReuseID";
    CardCell *cell = [self.tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        [self.tableView registerNib:[UINib nibWithNibName:@"CardCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
        cell = [self.tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    }
    
    [cell.countOne setImage:[UIImage imageNamed:@"star"]];
    [cell.countTwo setImage:[UIImage imageNamed:@"retweet"]];
    
    cell.likeCount.text = [NSString stringWithFormat:@"%i",[[[self.tweetsArray objectAtIndex:indexPath.row] objectForKey:@"favorite_count"] intValue]];
    cell.commentCount.text = [NSString stringWithFormat:@"%i",[[[self.tweetsArray objectAtIndex:indexPath.row] objectForKey:@"retweet_count"] intValue]];

    [cell.userPic sd_setImageWithURL:[NSURL URLWithString:[[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"user"] valueForKey:@"profile_image_url_https"]]
                 placeholderImage:[UIImage imageNamed:@"placeholder"] options:indexPath.row == 0 ? SDWebImageRefreshCached : 0];

    cell.username.text = [[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"user"]valueForKey:@"name"];
    
    //TODO also show raw username
    //lblScreenName.text = [NSString stringWithFormat:@"@%@",[[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"user"]valueForKey:@"screen_name"]];

    cell.shareUrl = [NSString stringWithFormat:@"https://twitter.com/%@/status/%@",
                     [[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"user"]valueForKey:@"screen_name"],
                     [self.tweetsArray[indexPath.row]valueForKey:@"id"]];
    
    cell.caption.text = [[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"text"] stringByDecodingHTMLEntities];
    
    //TODO See if this statement is simplefieable, and also do this in the cell view.
    if ([[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"extended_entities"] != nil &&
        [[[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"extended_entities"] valueForKey:@"media"] objectAtIndex:0] != nil &&
        [[[[[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"extended_entities"] valueForKey:@"media"]  objectAtIndex:0] valueForKey:@"type"] isEqualToString: @"photo"]) {

            NSString *imageUrl = [NSString stringWithFormat:@"%@",[[[[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"extended_entities"] valueForKey:@"media"] objectAtIndex:0]valueForKey:@"media_url"]];
        
            [cell.photoView sd_setImageWithURL:[NSURL URLWithString:imageUrl]
                          placeholderImage:[UIImage imageNamed:@"default_placeholder"] options:indexPath.row == 0 ? SDWebImageRefreshCached : 0];
            NSLog(@"%@",imageUrl);
            cell.photoView.hidden = NO;
    }else{
            cell.photoView.hidden = YES;
    }
    
    //lbldate.text=[NSString stringWithFormat:@"%@",[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"created_at"]];
    NSDateFormatter *df = [[NSDateFormatter alloc] init] ;
    //Wed Dec 01 17:08:03 +0000 2010
    [df setDateFormat:@"eee MMM dd HH:mm:ss ZZZZ yyyy"];
    
    NSDate *date = [df dateFromString:[NSString stringWithFormat:@"%@",[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"created_at"]]];
    
    [df setDateFormat:@"eee MMM dd yyyy"];
    NSString *dateStr = [df stringFromDate:date];
    cell.time.text=dateStr;
    
    //cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    //URL click handelers
    cell.caption.urlLinkTapHandler = ^(KILabel *label, NSString *string, NSRange range) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:string]];
    };
    
     cell.caption.hashtagLinkTapHandler = ^(KILabel *label, NSString *string, NSRange range) {
        UIApplication *app = [UIApplication sharedApplication];
        
        // NOTE: you must percent escape the query (# becomes %23)
        NSString *cleanQuery = [string stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *twitterURL = [NSURL URLWithString:[NSString stringWithFormat:@"twitter://search?query=%@", cleanQuery]];
        if ([app canOpenURL:twitterURL]) {
            [app openURL:twitterURL];
        } else {
            NSURL *safariURL = [NSURL URLWithString:[NSString stringWithFormat:@"http://mobile.twitter.com/search?q=%@", cleanQuery]];
            [app openURL:safariURL];
        }
    };
    
    cell.caption.userHandleLinkTapHandler = ^(KILabel *label, NSString *string, NSRange range) {
        UIApplication *app = [UIApplication sharedApplication];
        
        // NOTE: you must percent escape the query (# becomes %23)
        NSString *cleanQuery = [string stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *twitterURL = [NSURL URLWithString:[NSString stringWithFormat:@"twitter://user?screen_name=%@", cleanQuery]];
        if ([app canOpenURL:twitterURL]) {
            [app openURL:twitterURL];
        } else {
            NSURL *safariURL = [NSURL URLWithString:[NSString stringWithFormat:@"http://mobile.twitter.com/%@", cleanQuery]];
            [app openURL:safariURL];
        }
    };
    
    cell.delegate = self;
    
    return cell;

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES]; // if error remove "self."
    //twitterDetailViewController *twitter=[[twitterDetailViewController alloc]initWithNibName:@"twitterDetailViewController" bundle:nil];
    
    //twitter.openURl=[NSString stringWithFormat:@"https://twitter.com/%@/status/%@",
                    // [[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"user"]valueForKey:@"screen_name"],
                   //  [self.tweetsArray[indexPath.row]valueForKey:@"id"]];
    
    //NSDateFormatter *df = [[NSDateFormatter alloc] init] ;

    //[df setDateFormat:@"eee MMM dd HH:mm:ss ZZZZ yyyy"];
    
    //NSDate *date = [df dateFromString:[NSString stringWithFormat:@"%@",[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"created_at"]]];
    
    //[df setDateFormat:@"eee MMM dd yyyy"];
    //NSString *dateStr = [df stringFromDate:date];
    //twitter.dateString=dateStr;
    
    
    //twitter.imageURL=[[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"user"]valueForKey:@"profile_image_url_https"];
    //twitter.titleName=[[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"user"]valueForKey:@"name"];
    //twitter.screenName=[NSString stringWithFormat:@"@%@",[[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"user"]valueForKey:@"screen_name"]];
    
    //twitter.tweet=[[self.tweetsArray objectAtIndex:indexPath.row] valueForKey:@"text"];
    
    //[self.navigationController pushViewController:twitter animated:YES];
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dictionary = [self.tweetsArray objectAtIndex:indexPath.row];
    CGFloat height = [CardCell heightForRowWithData:dictionary forType:PageType_TWITTER forView:self.tableView];
    return height;
}

- (NSString *)loadAccessToken {
    return [[NSUserDefaults standardUserDefaults]objectForKey:@"SavedAccessHTTPBody"];
}

- (void)storeAccessToken:(NSString *)accessToken {
    [[NSUserDefaults standardUserDefaults]setObject:accessToken forKey:@"SavedAccessHTTPBody"];
}

@end
