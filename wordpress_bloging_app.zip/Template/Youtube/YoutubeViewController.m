//
// AssistTableViewController.m
//
// Copyright (c) 2015 Sherdle. All rights reserved.
//

#import "YoutubeViewController.h"
#import "AssistTableHeaderView.h"
#import "AssistTableFooterView.h"

#import "NSString+HTML.h"
#import "MWFeedParser.h"
#import "KILabel.h"
#import "SWRevealViewController.h"

#import "YoutubeDetailViewController.h"
#import "AppDelegate.h"

#import "CommonBanner.h"

#define HEADERVIEW_HEIGHT 175

@interface YoutubeViewController ()
// Private helper methods
- (void) addItemsOnTop;
- (void) addItemsOnBottom;

@end

@implementation YoutubeViewController
@synthesize urlString;

- (void) viewDidLoad
{
    [super viewDidLoad];
    
    if (ADS_ON)
        self.canDisplayAds = YES;
    
    formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateStyle:NSDateFormatterShortStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [self.tableView addGestureRecognizer: self.revealViewController.panGestureRecognizer];
    [self.tableView addGestureRecognizer: self.revealViewController.tapGestureRecognizer];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 20, 20);
    [btn setImage:[UIImage imageNamed:@"reveal-icon"] forState:UIControlStateNormal];
    [btn addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftBarButton = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
    self.navigationItem.leftBarButtonItem = leftBarButton;
    
    self.title = @"Loading...";
    
    // set the custom view for "pull to refresh". See AssistTableHeaderView.xib.
    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AssistTableHeaderView" owner:self options:nil];
    AssistTableHeaderView *headerView = (AssistTableHeaderView *)[nib objectAtIndex:0];
    self.headerView = headerView;
    
    // set the custom view for "load more". See AssistTableFooterView.xib.
    nib = [[NSBundle mainBundle] loadNibNamed:@"AssistTableFooterView" owner:self options:nil];
    AssistTableFooterView *footerView = (AssistTableFooterView *)[nib objectAtIndex:0];
    self.footerView = footerView;
    
    // add sample items
    [self firstFetchdata];
}


- (void)viewDidLayoutSubviews
{
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)])
        self.edgesForExtendedLayout = UIRectEdgeNone;
}

- (void)firstFetchdata
{
    parsedItems = [[NSMutableArray alloc]init];
    count=15;
    
    //    [self fetchdata:urlString IntValue:count];
    NSString *str;
    
    str=[NSString stringWithFormat:@"https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=%@&maxResults=%i&key=%@",urlString,15,YOUTUBE_CONTENT_KEY];
    
    NSLog(@"%@", str);
    NSURL *url = [[NSURL alloc]initWithString:[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSMutableURLRequest *req = [[NSMutableURLRequest alloc]initWithURL:url];
    
    
    [NSURLConnection sendAsynchronousRequest:req queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        if (data == nil) {
            [[[UIAlertView alloc]initWithTitle:@"Error" message:NO_CONNECTION_TEXT delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
            
            self.title= _navTitle;
            [self loadMoreCompleted];
            [self refreshCompleted];
            
            return ;
        }
        else  {
            jsonDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&connectionError];
            NSArray *jsonArray = [jsonDict valueForKey:@"items"];
            pageToken=[jsonDict valueForKey:@"nextPageToken"];
            
            //            NSLog(@"%@", jsonDict);
            
            //            parsedItems = [[NSMutableArray alloc]init];
            for (id result in jsonArray)
            {
                [parsedItems addObject:result];
            }
            
            [self.tableView reloadData];
            self.title= _navTitle;
            [self loadMoreCompleted];
            [self refreshCompleted];
        }
        
    }];
}

-(void)viewWillAppear:(BOOL)animated{
    if (parsedItems == nil) {
        parsedItems = [[NSMutableArray alloc] init];
    }
    
}
-(void)fetchdata:(NSString *)withCount IntValue:(int) setValue{
    //todo: verify (in addtion; can first condition be removed?
    if ((pageToken == nil || [pageToken isEqualToString:@""]) && parsedItems == nil) {
        parsedItems = [[NSMutableArray alloc]init];
        return;
    }
    NSString *str;
    
    str=[NSString stringWithFormat:@"https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=%@&maxResults=%i&key=%@&pageToken=%@",urlString,15,YOUTUBE_CONTENT_KEY,pageToken];
    //    str=[NSString stringWithFormat:@"https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=%@&maxResults=%i&key=%@&pagetoken=%@",urlString,count,YOUTUBE_CONTENT_KEY,pageToken];
    //    NSLog(@"%@", str);
    NSURL *url = [[NSURL alloc]initWithString:[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSMutableURLRequest *req = [[NSMutableURLRequest alloc]initWithURL:url];
    
    
    [NSURLConnection sendAsynchronousRequest:req queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        if (data == nil) {
            [[[UIAlertView alloc]initWithTitle:@"Error" message:NO_CONNECTION_TEXT delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
            return ;
        }
        else  {
            jsonDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&connectionError];
            NSArray *jsonArray = [jsonDict valueForKey:@"items"];
            pageToken=[jsonDict valueForKey:@"nextPageToken"];
            
            for (id result in jsonArray)
            {
                [parsedItems addObject:result];
            }
            
            [self.tableView reloadData];
            self.title= _navTitle;
            [self loadMoreCompleted];
            [self refreshCompleted];
        }
        
    }];
    
}

- (void) pinHeaderView
{
    [super pinHeaderView];
    
    // do custom handling for the header view
    AssistTableHeaderView *hv = (AssistTableHeaderView *)self.headerView;
    [hv.activityIndicator startAnimating];
    hv.title.text = @"Loading...";
}

- (void) unpinHeaderView
{
    [super unpinHeaderView];
    
    // do custom handling for the header view
    [[(AssistTableHeaderView *)self.headerView activityIndicator] stopAnimating];
}

- (void) headerViewDidScroll:(BOOL)willRefreshOnRelease scrollView:(UIScrollView *)scrollView
{
    AssistTableHeaderView *hv = (AssistTableHeaderView *)self.headerView;
    if (willRefreshOnRelease)
        hv.title.text = @"Release to refresh...";
    else
        hv.title.text = @"Pull down to refresh...";
}

- (BOOL) refresh
{
    if (![super refresh])
        return NO;
    
    // Do your async call here
    // This is just a dummy data loader:
    [self performSelector:@selector(addItemsOnTop) withObject:nil afterDelay:2.0];
    // See -addItemsOnTop for more info on how to finish loading
    return YES;
}

- (void) willBeginLoadingMore
{
    AssistTableFooterView *fv = (AssistTableFooterView *)self.footerView;
    [fv.activityIndicator startAnimating];
}

- (void) loadMoreCompleted
{
    [super loadMoreCompleted];
    
    AssistTableFooterView *fv = (AssistTableFooterView *)self.footerView;
    [fv.activityIndicator stopAnimating];
    
    if (!self.canLoadMore) {
        // Do something if there are no more items to load
        
        // We can hide the footerView by: [self setFooterViewVisibility:NO];
        
        // Just show a textual info that there are no more items to load
        fv.infoLabel.hidden = NO;
    }
}

- (BOOL) loadMore
{
    if (![super loadMore])
        return NO;
    
    // Do your async loading here
    [self performSelector:@selector(addItemsOnBottom) withObject:nil afterDelay:2.0];
    // See -addItemsOnBottom for more info on what to do after loading more items
    
    return YES;
}

- (void) addItemsOnTop
{
    [self fetchdata:urlString IntValue:15];
    
    // Call this to indicate that we have finished "refreshing".
    // This will then result in the headerView being unpinned (-unpinHeaderView will be called).
    
}

- (void) addItemsOnBottom
{
    count=count+15;
    
    [self fetchdata:urlString IntValue:count];
    
    
    
    NSString *totalC=[NSString stringWithFormat:@"%@",[[jsonDict valueForKey:@"pageInfo"]valueForKey:@"totalResults"]];
    
    int totalcount= (int)[totalC integerValue];
    
    if (parsedItems.count > totalcount)
        
        
        
        
        self.canLoadMore = NO; // signal that there won't be any more items to load
    else
        self.canLoadMore = YES;
    
    // Inform STableViewController that we have finished loading more items
    
}

- (NSString *) createRandomValue
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeStyle:NSDateFormatterMediumStyle];
    
    return [NSString stringWithFormat:@"%@ %@", [dateFormatter stringFromDate:[NSDate date]],
            [NSNumber numberWithInt:rand()]];
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"%lu", (unsigned long)parsedItems.count);
    if (parsedItems == nil) {
        return 0;
    }
    return parsedItems.count;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = [NSString stringWithFormat:@"%ld,%ld",(long)indexPath.section,(long)indexPath.row];
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    //  static NSString *CellIdentifier = @"Cell";
    if (indexPath.row == 0 && [parsedItems count] > 0){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        UIImageView *imgview = [[UIImageView alloc]
                                initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, HEADERVIEW_HEIGHT)];
        
        NSString *url=[[[[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"] valueForKey:@"thumbnails"] valueForKey:@"high"] valueForKey:@"url"];
        
        [imgview sd_setImageWithURL:[NSURL URLWithString:url]
                   placeholderImage:[UIImage imageNamed:@"default_placeholder"] options:indexPath.row == 0 ? SDWebImageRefreshCached : 0];
        [imgview setContentMode:UIViewContentModeScaleAspectFill];
        imgview.clipsToBounds = true;
        [cell addSubview:imgview];
        
        CGRect frame = CGRectMake(0, (HEADERVIEW_HEIGHT - 100) / 2, self.view.frame.size.width, 100);
        UIView *blueLayer = [[UIView alloc] initWithFrame: frame];
        CAGradientLayer *gradient = [CAGradientLayer layer];
        gradient.frame            = frame;
        gradient.colors           = [NSArray arrayWithObjects:(id)[[UIColor colorWithWhite:0 alpha:0] CGColor],(id)[[UIColor colorWithWhite:0 alpha:0.5] CGColor], nil];
        [blueLayer.layer insertSublayer:gradient atIndex:-1];
        [cell addSubview:blueLayer];
        
        KILabel *lbl1 = [[KILabel alloc] initWithFrame: CGRectMake(10, HEADERVIEW_HEIGHT - 75, self.view.frame.size.width - 20, 65)];
        
        //lbl1.backgroundColor=[UIColor redColor];
        lbl1.font = [UIFont systemFontOfSize: 20];
        lbl1.textColor=[UIColor whiteColor];
        [lbl1 setUserInteractionEnabled:NO];
        [lbl1 setAllignBottom: true];
        lbl1.numberOfLines = 0;
        lbl1.text= [[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"]valueForKey:@"title"];
        
        [cell addSubview:lbl1];
        
    } else {
        
        UILabel *lbltitle;
        UILabel *lblDate;
        UIImageView *imageView;
    
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            //	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
            NSInteger widthWithPaddingAndImg = self.view.frame.size.width - 135;
            
            lbltitle=[[UILabel alloc]init];
            [cell addSubview:lbltitle];
            lbltitle.frame=CGRectMake(135, 5, widthWithPaddingAndImg, 55);
        
            lbltitle.numberOfLines=4;
            lbltitle.font=[UIFont boldSystemFontOfSize:17];
        
            lblDate=[[UILabel alloc]init];
            [cell addSubview:lblDate];
            lblDate.numberOfLines=1;
            lblDate.frame=CGRectMake(135, 60, widthWithPaddingAndImg, 18);
            lblDate.lineBreakMode=NSLineBreakByCharWrapping;
        
            imageView=[[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 115, 65)];
            [cell addSubview:imageView];

            [lblDate setBackgroundColor:[UIColor clearColor]];
            [lbltitle  setBackgroundColor:[UIColor clearColor]];
            [imageView setBackgroundColor:[UIColor clearColor]];

            lbltitle.font = [UIFont boldSystemFontOfSize:15];
            lblDate.font = [UIFont systemFontOfSize:13];
        
        }
    
        if ([parsedItems count] > 0)
        {
            NSString *title=[[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"]valueForKey:@"title"];
            lbltitle.text= title;
        
            NSString *datestring= [[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"]valueForKey:@"publishedAt"];
        
            NSDateFormatter *dateFormatter=[NSDateFormatter new];
            [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSSZZZ"];

            NSDate *date11=[dateFormatter dateFromString:datestring];
            
            [dateFormatter setDateFormat:@"dd-MM-yyyy hh:mm"];
            lblDate.text =[dateFormatter stringFromDate:date11];
        
            [imageView sd_setImageWithURL:[NSURL URLWithString:[[[[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"] valueForKey:@"thumbnails"] valueForKey:@"default"] valueForKey:@"url"]]
                     placeholderImage:[UIImage imageNamed:@"youtube.png"] options:indexPath.row == 0 ? SDWebImageRefreshCached : 0];
            imageView.contentMode = UIViewContentModeScaleAspectFill;
            imageView.clipsToBounds = YES;
            
        } else {
            //No items
        }
    }
    
    return cell;
    
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0){
        return HEADERVIEW_HEIGHT;
    } else {
        return 85;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // Show detail
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSLog(@"%@",[[NSString stringWithFormat:@"http://www.youtube.com/watch?v=%@",[[[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"]valueForKey:@"resourceId"] valueForKey:@"videoId"]] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]);
    
    YoutubeDetailViewController *youtubeDetail=[
                                                [YoutubeDetailViewController alloc]initWithNibName:@"YoutubeDetailViewController" bundle:nil];
    
    youtubeDetail.summary=[[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"]valueForKey:@"description"];
    
    youtubeDetail.imageUrl=[[[[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"] valueForKey:@"thumbnails"] valueForKey:@"high"] valueForKey:@"url"];
    youtubeDetail.titleText=[[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"]valueForKey:@"title"];
    
    youtubeDetail.videoUrl=[[NSString stringWithFormat:@"http://www.youtube.com/watch?v=%@",[[[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"]valueForKey:@"resourceId"] valueForKey:@"videoId"]] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSString *datestring= [[[parsedItems objectAtIndex:indexPath.row] valueForKey:@"snippet"]valueForKey:@"publishedAt"];
    
    NSDateFormatter *dateFormatter=[NSDateFormatter new];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSSZZZ"];
    
    NSDate *date11=[dateFormatter dateFromString:datestring];
    
    
    youtubeDetail.date =[NSString stringWithFormat:@"%@",date11];

    [self.navigationController pushViewController:youtubeDetail animated:YES];
    
    
}

@end
