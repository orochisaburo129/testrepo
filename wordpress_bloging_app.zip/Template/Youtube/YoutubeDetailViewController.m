//
//  YoutubeDetailViewController.m
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#import "YoutubeDetailViewController.h"
#import "AppDelegate.h"
#import "UIImageView+WebCache.h"
#import "HCYoutubeParser.h"
#import <MediaPlayer/MediaPlayer.h>

#define LABEL_WIDTH self.articleDetail.tableView.frame.size.width - 20

@interface YoutubeDetailViewController (){
    UIView *blueLayer;
}

@end

@implementation YoutubeDetailViewController
@synthesize wrappedText;

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.articleDetail = [[DetailViewAssistant alloc] initWithFrame:self.view.bounds];
    self.articleDetail.tableViewDataSource = self;
    self.articleDetail.tableViewDelegate = self;
    
    self.articleDetail.delegate = self;
    self.articleDetail.parallaxScrollFactor = 0.3; // little slower than normal.
    
    [self.view addSubview:self.articleDetail];
    
    self.view.clipsToBounds = YES;
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
    
    _headerView.backgroundColor = APP_THEME_COLOR;
    
    self.articleDetail.headerView = _headerView;
    
    self.articleDetail.headerFade = 100.0f;
    self.articleDetail.defaultimagePagerHeight = 0.0f;

}

- (void)viewDidLayoutSubviews
{
    if (blueLayer == nil) {
        blueLayer = [[UIView alloc] initWithFrame: _headerView.bounds];
        CAGradientLayer *gradient = [CAGradientLayer layer];
        gradient.frame            = _headerView.bounds;
        gradient.colors           = [NSArray arrayWithObjects:(id)[[UIColor colorWithWhite:0 alpha:0.5] CGColor], (id)[[UIColor colorWithWhite:0 alpha:0] CGColor], nil];
        [blueLayer.layer insertSublayer:gradient atIndex:-1];
        [self.view addSubview:blueLayer];
    }
    
    [self.view bringSubviewToFront:_headerView];
    
    UIButton *buttonBack = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonBack.frame = CGRectMake(10, 21, 70, 44);
    [buttonBack addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    [buttonBack setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [buttonBack setExclusiveTouch:YES];
    [buttonBack setTitle:@"❰ Back" forState:UIControlStateNormal];
    [buttonBack.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Light" size:21.0]];
    [buttonBack setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.view addSubview:buttonBack];
    
    UIButton *buttonPost = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonPost.frame = CGRectMake(self.view.frame.size.width - 44, 18, 44, 44);
    [buttonPost setImage:[UIImage imageNamed:@"btn_post"] forState:UIControlStateNormal];
    [buttonPost addTarget:self action:@selector(share) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonPost];
    
    [self.view layoutIfNeeded];
    [super viewDidLayoutSubviews];
}

#pragma mark - UITableView

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0){
        return 180.0f;
    }
    else if(indexPath.row == 1){
        CGSize sizeBounds = CGSizeMake(LABEL_WIDTH,9999);
        CGRect textRect = [_titleText boundingRectWithSize:sizeBounds
                                             options:NSStringDrawingUsesLineFragmentOrigin
                                          attributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:21.0]}
                                             context:nil];
        
        CGSize size = textRect.size;
        return size.height + 50;
    }
    else if(indexPath.row == 2){
        return (_webViewDisplay.frame.size.height);
    }
    else if(indexPath.row == 3){
        return 60.0f;
    }
    else
        return 100.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"topImage"];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"topImage"];
        }
        
        UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 180)];
        [cell addSubview:imageView];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(0, 0, 50, 50);
        [btn setBackgroundImage:[UIImage imageNamed:@"play_button.png"] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(playVideo) forControlEvents:UIControlEventTouchUpInside];
        CGPoint centerImageView = btn.center;
        centerImageView = imageView.center;
        btn.center = centerImageView;
        [cell addSubview:btn];
        
        [imageView sd_setImageWithURL:[NSURL URLWithString:_imageUrl]
                                        placeholderImage:[UIImage imageNamed:@"default_placeholder"]];
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        imageView.clipsToBounds = true;
        
        return cell;
    }
    
    else if(indexPath.row == 1){
        TitleCell *cell = [tableView dequeueReusableCellWithIdentifier:@"titleCell"];
        
        if(cell == nil){
            cell = [TitleCell titleCell];
            cell.lblTitle.text = _titleText;
            cell.lblTitle.numberOfLines = 0;
            [cell.lblTitle sizeToFit];
            
            CGSize size = cell.lblTitle.bounds.size;
            NSInteger height = size.height;
            
            CGRect frameRect = cell.lblDescription.frame;
            cell.lblDescription.text = [NSString stringWithFormat:@"Published at %@", _date];
            cell.lblDescription.numberOfLines = 1;
            frameRect.origin.y = 20 + height;
            cell.lblDescription.frame = frameRect;
        }
        return cell;
    }
    
    else if(indexPath.row == 2){
        NSString *style = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"style" ofType:@"css"] encoding:NSUTF8StringEncoding error:nil];
        
        NSString *htmlContent = _summary;
        
        //Add the content to the another string with styling and the original html content
        NSString *htmlStyling = [NSString stringWithFormat:@"<html>"
                       "<head>"
                       "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0\" />"
                       "<style type=\"text/css\">"
                       "%@"
                       "</style>"
                       "</head>"
                       "<body>"
                       "<p>%@</p>"
                       "</body></html>", style, htmlContent];
        
        //Pass the value to another ViewController for displaying the content
        wrappedText = htmlStyling ;
        
        
        static NSString * webIndentifier = @"ShowPageCell";
        ShowPageCell *showCell = (ShowPageCell *)[tableView dequeueReusableCellWithIdentifier:webIndentifier];
        
        if (showCell == nil) {
            showCell = [ShowPageCell showPageCell];
        }
        
        showCell.indicator.hidden = YES;
        
        _webViewDisplay = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, self.articleDetail.tableView.frame.size.width, [self minHeightForText:wrappedText])];
        [_webViewDisplay loadHTMLString:wrappedText baseURL:nil];
        _webViewDisplay.delegate = self;
        _webViewDisplay.layer.cornerRadius = 0;
        _webViewDisplay.userInteractionEnabled = YES;
        _webViewDisplay.multipleTouchEnabled = YES;
        _webViewDisplay.clipsToBounds = YES;
        _webViewDisplay.scalesPageToFit = NO;
        _webViewDisplay.backgroundColor = [UIColor clearColor];
        _webViewDisplay.scrollView.scrollEnabled = NO;
        _webViewDisplay.scrollView.bounces = NO;
        [showCell addSubview:_webViewDisplay];
        
        return showCell;
    }
    else if(indexPath.row == 3){
        ActionCell *cell = [tableView dequeueReusableCellWithIdentifier:@"actionCell"];
        
        if(cell == nil){
            cell = [ActionCell actionCell];
            [cell.btnSave addTarget:self action:@selector(share) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnCheckin addTarget:self action:@selector(open) forControlEvents:UIControlEventTouchUpInside];
        }
        return cell;
    }
    else{
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"reusable"];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"reusable"];
        }
        
        cell.textLabel.text = @"Default cell";
        
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.contentView.backgroundColor = [UIColor whiteColor];
}

- (void)articleDetail:(DetailViewAssistant *)articleDetail tableViewDidLoad:(UITableView *)tableView
{
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}

- (void)articleDetail:(DetailViewAssistant *)articleDetail headerViewDidLoad:(UIView *)headerView
{
    [headerView setAlpha:0.0];
    [headerView setHidden:YES];
}

#pragma mark - Button actions

- (void)back
{
    [self.navigationController popToRootViewControllerAnimated:TRUE];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)open
{
    
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",_videoUrl]]];
}

- (void)share
{
    NSArray *activityItems = [NSArray arrayWithObjects:_videoUrl,  nil];
    
    //-- initialising the activity view controller
    UIActivityViewController *avc = [[UIActivityViewController alloc]
                                     initWithActivityItems:activityItems
                                     applicationActivities:nil];
    
    
    // avc.excludedActivityTypes = @[UIActivityTypePostToWeibo, UIActivityTypeAssignToContact, UIActivityTypeCopyToPasteboard,UIActivityTypePostToFacebook,UIActivityTypePostToTwitter,UIActivityTypePostToFlickr,UIActivityTypePostToVimeo,UIActivityTypeMessage ];
    
    [self.navigationController presentViewController:avc
                                            animated:YES
                                          completion:^{
                                              // ...
                                          }];
    
    //-- define the activity view completion handler
    avc.completionHandler = ^(NSString *activityType, BOOL completed){
        if (completed) {
            NSLog(@"Selected activity was performed.");
        } else {
            if (activityType == NULL) {
                NSLog(@"User dismissed the view controller without making a selection.");
            } else {
                NSLog(@"Activity was not performed.");
            }
        }
    };

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//TODO adjust this to new CSS file
- (CGFloat)minHeightForText:(NSString *)_text {
    if (!_textFont) {
        self.textFont = [UIFont boldSystemFontOfSize:16];
    }
    
    //Former sizewithfont
    //return [_text
    //        sizeWithFont:_textFont
    //        constrainedToSize:CGSizeMake(LABEL_WIDTH, 999999)
    //        lineBreakMode:NSLineBreakByWordWrapping
    //        ].height;
    
    CGRect textRect = [_text boundingRectWithSize:CGSizeMake(LABEL_WIDTH, 999999)
                                          options:NSStringDrawingUsesLineFragmentOrigin
                                       attributes:@{NSFontAttributeName:_textFont}
                                          context:nil];
    
    return textRect.size.height;
}

-(BOOL) webView:(UIWebView *)inWeb shouldStartLoadWithRequest:(NSURLRequest *)inRequest navigationType:(UIWebViewNavigationType)inType {
    if ( inType == UIWebViewNavigationTypeLinkClicked ) {
        [[UIApplication sharedApplication] openURL:[inRequest URL]];
        return NO;
    }
    
    return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)aWebView {
    CGRect frame = aWebView.frame;
    frame.size.height = 1;
    aWebView.frame = frame;
    // Asks the view to calculate and return the size that best fits its subviews.
    CGSize fittingSize = [aWebView sizeThatFits:CGSizeZero];
    frame.size = fittingSize;
    aWebView.frame = frame;
    [[self.articleDetail getTableView] beginUpdates];
    [[self.articleDetail getTableView] endUpdates];
}

- (void) playVideo {
    NSDictionary *videos = [HCYoutubeParser h264videosWithYoutubeURL:[NSURL URLWithString:_videoUrl
                                                                      ]];
    
    // Presents a MoviePlayerController with the youtube quality medium
    MPMoviePlayerViewController *mp = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:[videos objectForKey:@"medium"]]];
    
    [self presentViewController:mp animated:YES completion:nil];
    
    // To get a thumbnail for an image there is now a async method for that
    [HCYoutubeParser thumbnailForYoutubeURL:[NSURL URLWithString:_videoUrl]
             thumbnailSize:YouTubeThumbnailDefaultHighQuality
             completeBlock:^(UIImage *image, NSError *error) {
                    if (!error) {
                                      // self.thumbailImageView.image = image;
                    }
                    else {
                         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
                                      [alert show];
                    }
             }
     ];
    
    
}

@end
