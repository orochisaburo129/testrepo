//
//  YoutubeDetailViewController.h
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailViewAssistant.h"
#import "ActionCell.h"
#import "TitleCell.h"
#import "ShowPageCell.h"

@interface YoutubeDetailViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,UIWebViewDelegate,DetailViewAssistantDelegate>{
    ShowPageCell *showPageCell;
    NSMutableArray *parsedItems;
}

@property (nonatomic, strong) DetailViewAssistant *articleDetail;

@property (strong, nonatomic) UIWebView *webViewDisplay;
@property (nonatomic, retain) NSString *wrappedText;
@property (nonatomic, retain) NSString *titleText;
@property (nonatomic, retain) UIFont *textFont;

@property (strong,nonatomic) NSString *videoUrl;
@property (strong,nonatomic) NSString *imageUrl;
@property (strong,nonatomic) NSString *summary;
@property (strong,nonatomic) NSString *date;

@property (weak, nonatomic) IBOutlet UIView *headerView;
@property (weak, nonatomic) IBOutlet UILabel *headerTitle;
@end
