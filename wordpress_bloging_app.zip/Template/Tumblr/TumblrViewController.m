//
//  TumblrViewController.m
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#define iPhone5  ([[UIScreen mainScreen] bounds].size.height == 568)

#import "TumblrViewController.h"
#import "UIImageView+WebCache.h"
#import "SWRevealViewController.h"
#import "FooterView.h"
#import "AppDelegate.h"
#import "CommonBanner.h"

#define LOADING_CELL_IDENTIFIER @"LoadingItemCell"
#define ITEMS_PAGE_SIZE 4


int StartNumber=0;

@interface TumblrViewController ()
{
    IBOutlet UIScrollView *scrollViewImage;
    
    IBOutlet UIView *viewImage;
    
    UIImageView *largeImageView;
    
    int fooIndex;
    
    bool reachedEnd;
    
    NSString *stringImage;
}
@end

@implementation TumblrViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    if (ADS_ON)
        self.canDisplayAds = YES;
    
    [self.navigationController.navigationBar setTranslucent:NO];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 20, 20);
    [btn setImage:[UIImage imageNamed:@"reveal-icon"] forState:UIControlStateNormal];
    [btn addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *leftBarButton = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
    self.navigationItem.leftBarButtonItem = leftBarButton;
    
    self.view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc] init];
    _collectionView=[[UICollectionView alloc] initWithFrame:self.view.frame collectionViewLayout:layout];
    [_collectionView setDataSource:self];
    [_collectionView setDelegate:self];
    
    [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    [_collectionView setBackgroundColor:[UIColor groupTableViewBackgroundColor]];

    
    [_collectionView registerClass:[FooterView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"hxwHeader"];
    
    
    [self.view addSubview:_collectionView];
    
    NSInteger viewWidth = self.view.frame.size.width;
    NSInteger viewHeight = self.view.frame.size.height;
    
    //TODO image might appear behind toolbar
    viewImage.frame = CGRectMake(0, 0, viewWidth, viewHeight);
        
    largeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 64, viewWidth, viewHeight - 64)];
    
    largeImageView.contentMode = UIViewContentModeScaleAspectFill;
    //images.clipsToBounds = YES;
    
    largeImageView.backgroundColor=[UIColor grayColor];
    
    largeImageView.multipleTouchEnabled = YES;
    
    [largeImageView canBecomeFirstResponder];
    
    largeImageView.userInteractionEnabled = YES;
    
    UISwipeGestureRecognizer *rightRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(leftSwipeHandle:)];
    
    rightRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
    
    [largeImageView addGestureRecognizer:rightRecognizer];
    
    // Left Gesture
    UISwipeGestureRecognizer *leftRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(rightSwipeHandle:)];
    
    leftRecognizer.direction = UISwipeGestureRecognizerDirectionLeft;
    
    [largeImageView addGestureRecognizer:leftRecognizer];
    
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapDetected)];
    singleTap.numberOfTapsRequired = 1;
    [largeImageView setUserInteractionEnabled:YES];
    [largeImageView addGestureRecognizer:singleTap];
}


- (void)viewDidLayoutSubviews
{
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)])
        self.edgesForExtendedLayout = UIRectEdgeNone;
}

-(void)tapDetected{
    NSLog(@"single Tap on imageview");
    [viewImage removeFromSuperview];
    
}
-(void)viewWillAppear:(BOOL)animated{
    
    [self.navigationController.navigationBar setTranslucent:NO];
    NSLog(@"AAAAA %@", NSStringFromCGRect(self.view.frame));
    [_collectionView setFrame:self.view.bounds];
    [largeImageView setFrame:self.view.bounds];
    [self fetchDataWithNumber:StartNumber];
    StartNumber=StartNumber+30;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    FooterView *headView;
    
    if([kind isEqual:UICollectionElementKindSectionFooter])
    {
        headView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"hxwHeader" forIndexPath:indexPath];
            [headView.activityIndicator startAnimating];
    }
    
    return headView;
}

// do not forget header & footer size

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section {
    //header size
    if (!reachedEnd){
        CGSize size = {_collectionView.bounds.size.width,50};
        return size;
    } else {
        CGSize size = {_collectionView.bounds.size.width,0};
        return size;
    }
}


#pragma mark - Left & Right UISwipeGestures

- (void) rightSwipeHandle:(UISwipeGestureRecognizer *) gestureRecognizer
{
    
    if (fooIndex + 1>= [imagesArray count])
    {
        
    }
    else
    {
        fooIndex = fooIndex + 1;
        [self animationStart];
        
        NSLog(@"FooIndex %d", fooIndex);
        stringImage = [NSString stringWithFormat:@"%@", [[imagesArray objectAtIndex:fooIndex] valueForKey:@"photo-url-1280"]];
        NSLog(@"%lu", (unsigned long)[imagesArray count]);
        [largeImageView sd_setImageWithURL:[NSURL URLWithString:stringImage] placeholderImage:[UIImage imageNamed:@"wf.png"]];
        
    }
    
}

- (void) leftSwipeHandle:(UISwipeGestureRecognizer *) gestureRecognizer
{
    if (fooIndex > 0){
           [self animationStartFromLeft];
    }

    if (fooIndex < 0)
    {
        fooIndex = 0;
        
    }
    else if (fooIndex > [imagesArray count])
    {
        //        fooIndex = fooIndex - 2;
        fooIndex = (int)[imagesArray count] - 1;
        
        stringImage = [NSString stringWithFormat:@"%@", [[imagesArray objectAtIndex:fooIndex] valueForKey:@"photo-url-1280"]];
        
        [largeImageView sd_setImageWithURL:[NSURL URLWithString:stringImage] placeholderImage:[UIImage imageNamed:@"wf.png"]];
    }
    else
    {
        if (fooIndex == 0) {
            
        }
        else
        {
            fooIndex = fooIndex - 1;
        }
        
        stringImage = [NSString stringWithFormat:@"%@", [[imagesArray objectAtIndex:fooIndex] valueForKey:@"photo-url-1280"]];
        
        [largeImageView sd_setImageWithURL:[NSURL URLWithString:stringImage] placeholderImage:[UIImage imageNamed:@"wf.png"]];
    }
}


-(void)fetchDataWithNumber:(int)number{
    
    self.title=@"Loading...";
    
    NSString *strUrl=[NSString stringWithFormat:@"http://%@.tumblr.com/api/read/json?num=30&start=%i",self.urlString,number] ;
    NSLog(@"Url: %@", strUrl);
    
    NSURL *url = [[NSURL alloc]initWithString:[strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    
    NSMutableURLRequest *req = [[NSMutableURLRequest alloc]initWithURL:url];
    
    [req setHTTPMethod:@"GET"];
    
    //    [req setValue:[NSString stringWithFormat:@"%d", postData.length] forHTTPHeaderField:@"Content-Length"];
    [req setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [NSURLConnection sendAsynchronousRequest:req queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError)
     {
         
         if (data == nil) {
             [[[UIAlertView alloc]initWithTitle:@"Error" message:NO_CONNECTION_TEXT delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
             
             self.title = _navTitle;
             reachedEnd = true;
             
             [_collectionView reloadSections:[[NSIndexSet alloc] initWithIndex:0]];
             
             return ;
         } else {
         
         NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
         //NSLog(@"Response data = %@", str);
         
         // NSString *newString = [str substringToIndex:[str length]-1];
         //NSLog(@"%i ",str.length);
         
         
         NSMutableString *strrrrr = [NSMutableString stringWithString:str];
         [strrrrr deleteCharactersInRange:NSMakeRange([strrrrr length]-2, 2)];
         
         NSString *stringWithoutSpaces = [strrrrr
                                          stringByReplacingOccurrencesOfString:@"var tumblr_api_read = " withString:@""];
         //NSLog(@"%i ",strrrrr.length);
         
         NSData *dataNew = [stringWithoutSpaces dataUsingEncoding:NSUTF8StringEncoding];
         
         id jsonFecth=[NSJSONSerialization JSONObjectWithData:dataNew options:0 error:nil];
         
         json = jsonFecth;

         //NSLog(@"%@ ",json);
         
         if (!imagesArray){
             imagesArray=[[NSMutableArray alloc]init];
             //imagesArray = [jsonFecth valueForKey:@"posts"];
         }
         for (id result in [jsonFecth valueForKey:@"posts"]) {
             [imagesArray addObject:result];
         }
         
         NSLog(@"ARRAY COUNT %lu ",(unsigned long)imagesArray.count);
         
         [_collectionView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
         self.title= _navTitle;
         }
         
     }];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return imagesArray.count ;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
    
    
    {
        cell.backgroundColor=[UIColor whiteColor];
        
        NSInteger boxSize = ( self.view.frame.size.width - 20 ) / 3;
        
        images=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, boxSize, boxSize)];
        images.contentMode = UIViewContentModeScaleAspectFill;
        images.clipsToBounds = YES;
        images.tag=indexPath.row;
        
        [cell addSubview:images];
        
        //  [images setImageWithURL:[NSURL URLWithString:[[imagesArray objectAtIndex:indexPath.row]valueForKey:@"photo-url-100"]] placeholderImage:nil];
        NSString *url;
        
        @try {
            
            
            url=[[imagesArray objectAtIndex:indexPath.row]valueForKey:@"photo-url-1280"];
            [images sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:@"wf.png"]];
            
            
        }
        @catch (NSException *exception)
        {
            
            url=[[imagesArray objectAtIndex:indexPath.row]valueForKey:@"photo-url-500"];
            [images sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:@"wf.png"]];
            
        }
        
        @finally {
            
        }
        
        
    }
    
    
    
    
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [self.view addSubview:viewImage];
    
    stringImage = [[imagesArray objectAtIndex:indexPath.row] valueForKey:@"photo-url-1280"];
    
    //    fooIndex = [imagesArray indexOfObject:stringImage];
    
    //     NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:strignImage]];
    
    [largeImageView sd_setImageWithURL:[NSURL URLWithString:stringImage] placeholderImage:[UIImage imageNamed:@"wf.png"]];
    
    fooIndex = (int)indexPath.row;
    
    [scrollViewImage addSubview:largeImageView];
    [largeImageView addSubview:_viewShare];
    
    
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger boxSize = ( self.view.frame.size.width - 20 ) / 3;
    return CGSizeMake(boxSize, boxSize);
}

- (void) animationStart
{
    CATransition* transition = [CATransition animation];
    transition.duration = 0.2;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush; //kCATransitionMoveIn; //, kCATransitionPush, kCATransitionReveal, kCATransitionFade
    transition.subtype = kCATransitionFromRight; //kCATransitionFromLeft, kCATransitionFromRight, kCATransitionFromTop, kCATransitionFromBottom
    
    [scrollViewImage.layer addAnimation:transition forKey:nil];
}

- (void) animationStartFromLeft
{
    CATransition* transition = [CATransition animation];
    transition.duration = 0.2;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush; //kCATransitionMoveIn; //, kCATransitionPush, kCATransitionReveal, kCATransitionFade
    transition.subtype = kCATransitionFromLeft; //kCATransitionFromLeft, kCATransitionFromRight, kCATransitionFromTop, kCATransitionFromBottom
    
    [scrollViewImage.layer addAnimation:transition forKey:nil];
}

- (IBAction)btnShare:(id)sender {
    NSArray *activityItems = [NSArray arrayWithObjects:largeImageView.image,  nil];
    
    //-- initialising the activity view controller
    UIActivityViewController *avc = [[UIActivityViewController alloc]
                                     initWithActivityItems:activityItems
                                     applicationActivities:nil];
    
    
    [self.navigationController presentViewController:avc
                                            animated:YES
                                          completion:^{
                                              // ...
                                          }];
    
    //-- define the activity view completion handler
    avc.completionHandler = ^(NSString *activityType, BOOL completed){
        if (completed) {
            NSLog(@"Selected activity was performed.");
        } else {
            if (activityType == NULL) {
                NSLog(@"User dismissed the view controller without making a selection.");
            } else {
                NSLog(@"Activity was not performed.");
            }
        }
    };
}

- (IBAction)btnSave:(id)sender {
    
    [[[UIAlertView alloc]initWithTitle:@"Message" message:@"Image saved sucessfully" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show ];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImageWriteToSavedPhotosAlbum(largeImageView.image, nil, nil, nil);
    });
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    float bottomEdge = scrollView.contentOffset.y + scrollView.frame.size.height;
    if (bottomEdge >= scrollView.contentSize.height)
    {
        
        NSString *str= [json valueForKey:@"posts-total"];
        
        int value=(int)[str integerValue];
        if (StartNumber < value) {
            reachedEnd = false;
            [self fetchDataWithNumber:StartNumber];
        } else {
            reachedEnd = true;
            [_collectionView reloadSections:[[NSIndexSet alloc] initWithIndex:0]];
        }
        
        StartNumber=StartNumber+30;
        
        
        // we are at the end
    }
}
@end
