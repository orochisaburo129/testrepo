
//
//  FooterView.m
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#import "FooterView.h"

@interface FooterView()

@property (strong, nonatomic) UILabel *label;

@end

@implementation FooterView

@synthesize activityIndicator;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.activityIndicator = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray] init];
        
        [self addSubview:self.activityIndicator];
        [self.activityIndicator setCenter:self.center];
    }
    return self;
}

@end
