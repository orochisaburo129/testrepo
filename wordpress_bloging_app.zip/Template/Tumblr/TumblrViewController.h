//
//  TumblrViewController.h
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TumblrViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
{
    UICollectionView *_collectionView;
    NSMutableArray *imagesArray;
    UIImageView * images;
    NSInteger _currentPage;
    id json;
    
}
@property(strong,nonatomic)UIScrollView *scrollView;
- (IBAction)btnShare:(id)sender;

- (IBAction)btnSave:(id)sender;

@property(strong,nonatomic)NSString *urlString;
@property(strong,nonatomic)NSString *navTitle;

@property (strong, nonatomic) IBOutlet UIView *viewShare;
@end
