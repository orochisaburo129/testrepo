//
//  DetailViewAssistant.h
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//
//  Implements TGFoursquareLocationDetail-Demo
//  Copyright (c) 2013 Thibault Guégan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DetailViewAssistantDelegate;

@interface DetailViewAssistant : UIView <UIScrollViewDelegate>

@property (nonatomic) CGFloat defaultimagePagerHeight;

/**
 How fast is the table view scrolling with the image picker
*/
@property (nonatomic) CGFloat parallaxScrollFactor;

@property (nonatomic) CGFloat headerFade;

@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic) CGRect defaultimagePagerFrame;

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) UIView *backgroundView;

@property (nonatomic, strong) UIColor *backgroundViewColor;

@property (nonatomic, strong) UIView *headerView;

@property (nonatomic, weak) id<UITableViewDataSource> tableViewDataSource;

@property (nonatomic, weak) id<UITableViewDelegate> tableViewDelegate;

@property (nonatomic, weak) id<DetailViewAssistantDelegate> delegate;

- (UITableView *)getTableView;

@end

@protocol DetailViewAssistantDelegate <NSObject>

@optional

- (void)articleDetail:(DetailViewAssistant *)articleDetail
      tableViewDidLoad:(UITableView *)tableView;

- (void)articleDetail:(DetailViewAssistant *)articleDetail
      headerViewDidLoad:(UIView *)headerView;

- (void)articleDetail:(DetailViewAssistant *)articleDetail
      topImageDidLoad:(UIView *)headerView;
@end
