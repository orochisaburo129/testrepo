//
//  DetailLocationCell.h
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//
//  Implements TGFoursquareLocationDetail-Demo
//  Copyright (c) 2013 Thibault Guégan. All rights reserved.
//
//

#import <UIKit/UIKit.h>

@interface ActionCell : UITableViewCell

+ (ActionCell*) actionCell;

@property (weak, nonatomic) IBOutlet UIButton *btnSave;
@property (weak, nonatomic) IBOutlet UIButton *btnCheckin;
@end
