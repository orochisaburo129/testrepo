//
//  TitleCell.h
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//
//  Implements TGFoursquareLocationDetail-Demo
//  Copyright (c) 2013 Thibault Guégan. All rights reserved.
//
//

#import <UIKit/UIKit.h>

@interface TitleCell : UITableViewCell

+ (TitleCell*) titleCell;

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblDescription;
@end
