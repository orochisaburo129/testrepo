//
//  ShowPageCell.h
//
//  Implements: KnomeiOS-SSO
//  Copyright (c) 2013 tcs. All rights reserved.
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//
//

#import <UIKit/UIKit.h>

@interface ShowPageCell : UITableViewCell

+ (ShowPageCell*) showPageCell;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicator;

@end
