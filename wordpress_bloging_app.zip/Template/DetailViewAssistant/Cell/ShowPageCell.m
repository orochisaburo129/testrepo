//
//  ShowPageCell.m
//
//  Implements: KnomeiOS-SSO
//  Created by tcs on 19/10/13.
//  Copyright (c) 2013 tcs. All rights reserved.
//

#import "ShowPageCell.h"

@implementation ShowPageCell

+ (ShowPageCell*) showPageCell
{
    ShowPageCell * cell = [[[NSBundle mainBundle] loadNibNamed:@"ShowPageCell" owner:self options:nil] objectAtIndex:0];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)layoutSubviews {
	[super layoutSubviews];
}

@end
