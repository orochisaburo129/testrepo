//
//  WordpressDetailViewController.m
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#import "WordpressDetailViewController.h"
#import "AppDelegate.h"
#import "UIImageView+WebCache.h"
#import "NSString+HTML.h"

#define LABEL_WIDTH self.articleDetail.tableView.frame.size.width - 20

@interface WordpressDetailViewController (){
    UIView *blueLayer;
}

@end

@implementation WordpressDetailViewController
@synthesize wrappedText;

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.articleDetail = [[DetailViewAssistant alloc] initWithFrame:self.view.bounds];
    self.articleDetail.tableViewDataSource = self;
    self.articleDetail.tableViewDelegate = self;
    
    self.articleDetail.delegate = self;
    self.articleDetail.parallaxScrollFactor = 0.3; // little slower than normal.
    
    [self.view addSubview:self.articleDetail];
    
    self.view.clipsToBounds = YES;
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
    
    _headerView.backgroundColor = APP_THEME_COLOR;
    
    NSString *authorAddition = @"";
    if ([_author length] > 0){
        authorAddition = [NSString stringWithFormat:@"written by %@", _author];
    }
    
    _subTitleText = [NSString stringWithFormat:@"Published at %@ %@", _date, authorAddition];

    
    self.articleDetail.headerView = _headerView;
    
    NSString *strURl=[NSString stringWithFormat:@"%@get_post/?post_id=%@",_mainURL,_detailID];
    NSLog(@"%@get_post/?post_id=%@", _mainURL,_detailID);
    
    NSMutableURLRequest *req = [[NSMutableURLRequest alloc]initWithURL:[NSURL URLWithString:strURl]];
    
    _html = @"";
    
    [NSURLConnection sendAsynchronousRequest:req queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        // [self performSelectorOnMainThread:@selector(hideProgressForView:) withObject:self.navigationController.view waitUntilDone:NO];
        if (data == nil) {
            [[[UIAlertView alloc]initWithTitle:@"Error" message:NO_CONNECTION_TEXT delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
            
            return ;
        }
        else  {
            
            NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&connectionError];
            NSArray *jsonArray = [jsonDict valueForKey:@"post"];
            
            NSLog(@"json result %@ ",[jsonArray valueForKey:@"title"]);
            
            NSLog(@"json dict  %@ ",[[jsonDict valueForKey:@"title"]valueForKey:@"title"]);
            
            NSLog(@"jsonArray = %@",jsonArray);
            
            //NSString *itemTitle = [jsonArray valueForKey:@"title"];
            //NSString *date= [jsonArray valueForKey:@"date"];
            
            _html =  [jsonArray valueForKey:@"content"]; // the post content
            
            //TODO Removing the first image, might not always be necesairy!
            
            NSString *regexStr = @"<img ([^>]+)>";
            
            NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:regexStr options:NSRegularExpressionCaseInsensitive error:NULL];
            NSRange range = [regex rangeOfFirstMatchInString:_html options:kNilOptions range:NSMakeRange(0, [_html length])];

            if (range.location != NSNotFound){
                _html = [regex stringByReplacingMatchesInString:_html options:0 range:range withTemplate:@"$2"];
            }
            
            NSIndexPath* indexPath1 = [NSIndexPath indexPathForRow:1 inSection:0];
            // Add them in an index path array
            NSArray* indexArray = [NSArray arrayWithObjects:indexPath1, nil];
            // Launch reload for the two index path
            [self.articleDetail.tableView reloadRowsAtIndexPaths:indexArray withRowAnimation:UITableViewRowAnimationFade];
        }
        
    }];

    
    /// No header image? Hide the image top view.
    if (!_imageUrl) {
        self.articleDetail.headerFade = -9999.0f;
        self.articleDetail.defaultimagePagerHeight = 60.0f;
    }

}

- (void)viewDidLayoutSubviews
{
    if (blueLayer == nil) {
    blueLayer = [[UIView alloc] initWithFrame: _headerView.bounds];
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame            = _headerView.bounds;
    gradient.colors           = [NSArray arrayWithObjects:(id)[[UIColor colorWithWhite:0 alpha:0.5] CGColor], (id)[[UIColor colorWithWhite:0 alpha:0] CGColor], nil];
    [blueLayer.layer insertSublayer:gradient atIndex:-1];
    [self.view addSubview:blueLayer];
    }
    
    [self.view bringSubviewToFront:_headerView];
    
    UIButton *buttonBack = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonBack.frame = CGRectMake(10, 21, 70, 44);
    [buttonBack addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    [buttonBack setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [buttonBack setExclusiveTouch:YES];
    [buttonBack setTitle:@"❰ Back" forState:UIControlStateNormal];
    [buttonBack.titleLabel setFont:[UIFont fontWithName:@"Helvetica-Light" size:21.0]];
    [buttonBack setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.view addSubview:buttonBack];
    
    UIButton *buttonPost = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonPost.frame = CGRectMake(self.view.frame.size.width - 44, 18, 44, 44);
    [buttonPost setImage:[UIImage imageNamed:@"btn_post"] forState:UIControlStateNormal];
    [buttonPost addTarget:self action:@selector(share) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonPost];
    
    [self.view layoutIfNeeded];
    [super viewDidLayoutSubviews];
}

#pragma mark - UITableView

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0){
        CGSize sizeBounds = CGSizeMake(LABEL_WIDTH,9999);
        CGRect textRect = [[_titleText stringByDecodingHTMLEntities] boundingRectWithSize:sizeBounds
                                             options:NSStringDrawingUsesLineFragmentOrigin
                                          attributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:21.0]}
                                             context:nil];
        
        CGRect subTextRect = [[_subTitleText stringByDecodingHTMLEntities] boundingRectWithSize:sizeBounds
                                                                                  options:NSStringDrawingUsesLineFragmentOrigin
                                                                               attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14.0]}
                                                                                  context:nil];
        
        return textRect.size.height + subTextRect.size.height + 25;
    }
    else if(indexPath.row == 1){
        if (_webViewDisplay.frame.size.height < 50){
            return 50.0f;
        } else {
            return (_webViewDisplay.frame.size.height);
        }
    }
    else if(indexPath.row == 2){
        return 60.0f;
    }
    else
        return 100.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if(indexPath.row == 0){
        TitleCell *cell = [tableView dequeueReusableCellWithIdentifier:@"titleCell"];
        
        if(cell == nil){
            cell = [TitleCell titleCell];
            cell.lblTitle.text = [_titleText stringByDecodingHTMLEntities];
            cell.lblTitle.numberOfLines = 0;
            [cell.lblTitle sizeToFit];
            
            CGSize size = cell.lblTitle.bounds.size;
            NSInteger height = size.height;
            
            CGRect frameRect = cell.lblDescription.frame;
            cell.lblDescription.text = _subTitleText;
            cell.lblDescription.numberOfLines = 0;
            [cell.lblTitle sizeToFit];
            
            frameRect.origin.y = cell.lblDescription.bounds.size.height + height;
            cell.lblDescription.frame = frameRect;
        }
        return cell;
    }
    
    else if(indexPath.row == 1){
        NSString *style = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"style" ofType:@"css"] encoding:NSUTF8StringEncoding error:nil];
        
        NSString *htmlContent = _html;
        
        //Add the content to the another string with styling and the original html content
        NSString *htmlStyling = [NSString stringWithFormat:@"<html>"
                       "<head>"
                       "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0\" />"
                       "<style type=\"text/css\">"
                       "%@"
                       "</style>"
                       "</head>"
                       "<body>"
                       "<p>%@</p>"
                       "</body></html>", style, htmlContent];
        
        //Pass the value to another ViewController for displaying the content
        wrappedText = htmlStyling ;
        
        
        static NSString * webIndentifier = @"ShowPageCell";
        ShowPageCell *showCell = (ShowPageCell *)[tableView dequeueReusableCellWithIdentifier:webIndentifier];
        
        if (showCell == nil) {
            showCell = [ShowPageCell showPageCell];
        }
                
        _webViewDisplay = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, self.articleDetail.tableView.frame.size.width, [self minHeightForText:wrappedText])];
        [_webViewDisplay loadHTMLString:wrappedText baseURL:nil];
        _webViewDisplay.delegate = self;
        _webViewDisplay.layer.cornerRadius = 0;
        _webViewDisplay.userInteractionEnabled = YES;
        _webViewDisplay.multipleTouchEnabled = YES;
        _webViewDisplay.clipsToBounds = YES;
        _webViewDisplay.scalesPageToFit = NO;
        _webViewDisplay.backgroundColor = [UIColor clearColor];
        _webViewDisplay.scrollView.scrollEnabled = NO;
        _webViewDisplay.scrollView.bounces = NO;
        [showCell addSubview:_webViewDisplay];
        
        return showCell;
    }
    else if(indexPath.row == 2){
        ActionCell *cell = [tableView dequeueReusableCellWithIdentifier:@"actionCell"];
        
        if(cell == nil){
            cell = [ActionCell actionCell];
            [cell.btnSave addTarget:self action:@selector(share) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnCheckin addTarget:self action:@selector(open) forControlEvents:UIControlEventTouchUpInside];
        }
        return cell;
    }
    else{
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"reusable"];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"reusable"];
        }
        
        cell.textLabel.text = @"Default cell";
        
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.contentView.backgroundColor = [UIColor whiteColor];
}

- (void)articleDetail:(DetailViewAssistant *)articleDetail tableViewDidLoad:(UITableView *)tableView
{
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}

- (void)articleDetail:(DetailViewAssistant *)articleDetail headerViewDidLoad:(UIView *)headerView
{
    [headerView setAlpha:0.0];
    [headerView setHidden:YES];
}

- (void)articleDetail:(DetailViewAssistant *)articleDetail topImageDidLoad:(UIView *)headerView
{
    if (_imageUrl) {
        [self.articleDetail.imageView sd_setImageWithURL:[NSURL URLWithString:_imageUrl]
                                        placeholderImage:[UIImage imageNamed:@"default_placeholder"]];
         self.articleDetail.imageView.contentMode = UIViewContentModeScaleAspectFill;
    }
}

#pragma mark - Button actions

- (void)back
{
    [self.navigationController popToRootViewControllerAnimated:TRUE];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)open
{
    
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",_articleUrl]]];
}

- (void)share
{
    NSArray *activityItems = [NSArray arrayWithObjects:_articleUrl,  nil];
    
    //-- initialising the activity view controller
    UIActivityViewController *avc = [[UIActivityViewController alloc]
                                     initWithActivityItems:activityItems
                                     applicationActivities:nil];
    
    
    // avc.excludedActivityTypes = @[UIActivityTypePostToWeibo, UIActivityTypeAssignToContact, UIActivityTypeCopyToPasteboard,UIActivityTypePostToFacebook,UIActivityTypePostToTwitter,UIActivityTypePostToFlickr,UIActivityTypePostToVimeo,UIActivityTypeMessage ];
    
    [self.navigationController presentViewController:avc
                                            animated:YES
                                          completion:^{
                                              // ...
                                          }];
    
    //-- define the activity view completion handler
    avc.completionHandler = ^(NSString *activityType, BOOL completed){
        if (completed) {
            NSLog(@"Selected activity was performed.");
        } else {
            if (activityType == NULL) {
                NSLog(@"User dismissed the view controller without making a selection.");
            } else {
                NSLog(@"Activity was not performed.");
            }
        }
    };

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//TODO adjust this to new CSS file
- (CGFloat)minHeightForText:(NSString *)_text {
    if (!_textFont) {
        self.textFont = [UIFont boldSystemFontOfSize:16];
    }
    
    CGRect textRect = [_text boundingRectWithSize:CGSizeMake(LABEL_WIDTH, 999999)
                                         options:NSStringDrawingUsesLineFragmentOrigin
                                      attributes:@{NSFontAttributeName:_textFont}
                                         context:nil];
    
    return textRect.size.height;
}

-(BOOL) webView:(UIWebView *)inWeb shouldStartLoadWithRequest:(NSURLRequest *)inRequest navigationType:(UIWebViewNavigationType)inType {
    if ( inType == UIWebViewNavigationTypeLinkClicked ) {
        [[UIApplication sharedApplication] openURL:[inRequest URL]];
        return NO;
    }

    if ([[[inRequest URL] absoluteString] rangeOfString:@"youtube.com/watch" options:NSCaseInsensitiveSearch].location == NSNotFound) {
        //NSLog(@"Does not contain youtube.com/watch %@", [[inRequest URL] absoluteString]);
    } else {
        [[UIApplication sharedApplication] openURL:[inRequest URL]];
        return NO;
        //NSLog(@"Does contain youtube.com/watch %@", [[inRequest URL] absoluteString]);
    }
    
    return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)aWebView {
    CGRect frame = aWebView.frame;
    frame.size.height = 1;
    aWebView.frame = frame;
    // Asks the view to calculate and return the size that best fits its subviews.
    CGSize fittingSize = [aWebView sizeThatFits:CGSizeZero];
    frame.size = fittingSize;
    aWebView.frame = frame;
    [[self.articleDetail getTableView] beginUpdates];
    [[self.articleDetail getTableView] endUpdates];
    
    //TODO The spinner in the ShowPageCell is magically hidden, but we might want to also hide it from code
}


@end
