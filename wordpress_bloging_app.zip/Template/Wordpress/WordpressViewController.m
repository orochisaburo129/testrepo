//
// WordpressViewController.m
//
// Copyright (c) 2015 Sherdle. All rights reserved.
//


#import "WordpressViewController.h"
#import "AssistTableHeaderView.h"
#import "AssistTableFooterView.h"

#import "NSString+HTML.h"
#import "MWFeedParser.h"

#import "WordpressDetailViewController.h"
#import "SWRevealViewController.h"
#import "KILabel.h"
#import "AppDelegate.h"
#import "CommonBanner.h"

#define HEADERVIEW_HEIGHT 175
#define WORDPRESSCORRECTION true

@interface WordpressViewController ()
// Private helper methods
- (void) addItemsOnTop;
- (void) addItemsOnBottom;
@end

@implementation WordpressViewController
@synthesize urlString,mainURL;

- (void) viewDidLoad
{
    [super viewDidLoad];
    if (ADS_ON)
        self.canDisplayAds = YES;
    
    [self.tableView addGestureRecognizer: self.revealViewController.panGestureRecognizer];
    [self.tableView addGestureRecognizer: self.revealViewController.tapGestureRecognizer];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 20, 20);
    [btn setImage:[UIImage imageNamed:@"reveal-icon"] forState:UIControlStateNormal];
    [btn addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftBarButton = [[UIBarButtonItem alloc]initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem = leftBarButton;
    
    if (WORDPRESSCORRECTION)
    page = -1;
    
    self.title = @"Loading...";
    
    // set the custom view for "pull to refresh". See AssistTableHeaderView.xib.
    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AssistTableHeaderView" owner:self options:nil];
    AssistTableHeaderView *headerView = (AssistTableHeaderView *)[nib objectAtIndex:0];
    self.headerView = headerView;
    
    // set the custom view for "load more". See AssistTableFooterView.xib.
    nib = [[NSBundle mainBundle] loadNibNamed:@"AssistTableFooterView" owner:self options:nil];
    AssistTableFooterView *footerView = (AssistTableFooterView *)[nib objectAtIndex:0];
    self.footerView = footerView;
    
}

- (void)viewDidLayoutSubviews
{
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)])
        self.edgesForExtendedLayout = UIRectEdgeNone;
}

-(void)viewWillAppear:(BOOL)animated{
    //count=15;
    
    //    [self fetchDataWith:urlString intValue:count];
    
    
}
-(void) fetchDataWith:(NSString *)withCount intValue:(int) setValue
{
    NSString *strURl;
    
    if ([urlString isEqualToString:@"latest"])
    {
        strURl=[NSString stringWithFormat:@"%@get_recent_posts/?page=%i&dev=1",mainURL,page];
    }
    else{
        
        strURl=[NSString stringWithFormat:@"%@get_category_posts/?page=%i&slug=%@&dev=1",mainURL,page,urlString];
    }
    
    if (urlString.length == 0 )
    {
        strURl=[NSString stringWithFormat:@"%@get_recent_posts/?page=%i&dev=1",mainURL,page];
    }
    NSLog(@"%@",strURl);
    
    NSMutableURLRequest *req = [[NSMutableURLRequest alloc]initWithURL:[NSURL URLWithString:strURl]];
    
    
    [NSURLConnection sendAsynchronousRequest:req queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        // [self performSelectorOnMainThread:@selector(hideProgressForView:) withObject:self.navigationController.view waitUntilDone:NO];
        if (data == nil) {
            [[[UIAlertView alloc]initWithTitle:@"Error" message:NO_CONNECTION_TEXT delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
            
            [self refreshCompleted];
            [self loadMoreCompleted];
            
            self.title = _navTitle;
            
            return ;
        }
        else  {
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                
                jsonDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
                
                NSArray *jsonArray = [jsonDict valueForKey:@"posts"];
                
                //NSLog(@"jsonArray = %@",jsonArray);
                
                if (!parsedItems){
                    parsedItems = [[NSMutableArray alloc]init];
                }
                for (NSArray *resultkey in jsonArray) {
                    NSMutableArray *result = [resultkey mutableCopy];
                    
                    //TODO, search for thumbnail in specific to store and use seperately.
                    NSString *htmlString = [result valueForKey:@"excerpt"];
                    NSString *url = @"";
                    NSArray *attachments= [result valueForKey:@"attachments"];
                    NSObject *thumbnails= [result valueForKey:@"thumbnail_images"];
                    if ([attachments count] > 0 && [NSNull null] != [[attachments objectAtIndex:0] valueForKey:@"url"]){
                        url= [[attachments objectAtIndex:0] valueForKey:@"url"];
                    } else if ([NSNull null] != thumbnails && [thumbnails valueForKey:@"medium"] != nil){
                        url= [[thumbnails valueForKey:@"medium"] valueForKey:@"url"];
                    } else {
                        NSScanner *theScanner = [NSScanner scannerWithString:htmlString];
                        // find start of IMG tag
                        [theScanner scanUpToString:@"<img" intoString:nil];
                        if (![theScanner isAtEnd]) {
                            [theScanner scanUpToString:@"src" intoString:nil];
                            NSCharacterSet *charset = [NSCharacterSet characterSetWithCharactersInString:@"\"'"];
                            [theScanner scanUpToCharactersFromSet:charset intoString:nil];
                            [theScanner scanCharactersFromSet:charset intoString:nil];
                            [theScanner scanUpToCharactersFromSet:charset intoString:&url];
                        }
                        // "url" now contains the URL of the img
                    }
                    
                    [result setValue:url forKey:@"mediaUrl"];
                    
                    NSString *authorname = @"";
                    NSObject *author;
                    
                    if ([result valueForKey:@"author"] != nil){
                        if ([[result valueForKey:@"author"] isKindOfClass:[NSArray class]] && [[result valueForKey:@"author"] count] > 0){
                            author = [[result valueForKey:@"author"] objectAtIndex:0];
                        } else {
                            author = [result valueForKey:@"author"];
                        }
                        
                        if ([author isKindOfClass:[NSObject class]] && [author valueForKey:@"name"] != nil){
                            authorname = [author valueForKey:@"name"];
                        }
                    }
                    
                    [result setValue:authorname forKey:@"author"];
                    
                    [parsedItems addObject:result];
                }
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.title= _navTitle;
                    
                    [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
                    
                    [self loadMoreCompleted];
                    [self refreshCompleted];
                });
            });
            
        }
        
    }];
    
}

- (void) pinHeaderView
{
    [super pinHeaderView];
    
    // do custom handling for the header view
    AssistTableHeaderView *hv = (AssistTableHeaderView *)self.headerView;
    [hv.activityIndicator startAnimating];
    hv.title.text = @"Loading...";
}

- (void) unpinHeaderView
{
    [super unpinHeaderView];
    
    // do custom handling for the header view
    [[(AssistTableHeaderView *)self.headerView activityIndicator] stopAnimating];
}

- (void) headerViewDidScroll:(BOOL)willRefreshOnRelease scrollView:(UIScrollView *)scrollView
{
    AssistTableHeaderView *hv = (AssistTableHeaderView *)self.headerView;
    if (willRefreshOnRelease)
        hv.title.text = @"Release to refresh...";
    else
        hv.title.text = @"Pull down to refresh...";
}


- (BOOL) refresh
{
    if (![super refresh])
        return NO;
    
    //TODO implement real time
    [self performSelector:@selector(addItemsOnTop) withObject:nil afterDelay:2.0];
    // See -addItemsOnTop for more info on how to finish loading
    return YES;
}

- (void) willBeginLoadingMore
{
    AssistTableFooterView *fv = (AssistTableFooterView *)self.footerView;
    [fv.activityIndicator startAnimating];
}

- (void) loadMoreCompleted
{
    [super loadMoreCompleted];
    
    AssistTableFooterView *fv = (AssistTableFooterView *)self.footerView;
    [fv.activityIndicator stopAnimating];
    
    if (!self.canLoadMore) {
        // Do something if there are no more items to load
        
        // We can hide the footerView by: [self setFooterViewVisibility:NO];
        
        // Just show a textual info that there are no more items to load
        fv.infoLabel.hidden = NO;
    }
}

- (BOOL) loadMore
{
    if (![super loadMore])
        return NO;
    
    // Do your async loading here
    [self performSelector:@selector(addItemsOnBottom) withObject:nil afterDelay:2.0];
    // See -addItemsOnBottom for more info on what to do after loading more items
    
    return YES;
}

- (void) addItemsOnTop
{
    parsedItems = nil;
    page = 0;
    [self fetchDataWith:urlString intValue:1];
    
    
    // Call this to indicate that we have finished "refreshing".
    // This will then result in the headerView being unpinned (-unpinHeaderView will be called).
    [self refreshCompleted];
}

- (void) addItemsOnBottom
{
    NSString *total;
    
    total=[NSString stringWithFormat:@"%@",[jsonDict valueForKey:@"pages"]];
    
    page=page+1;
    if (page == 1 && WORDPRESSCORRECTION){
        page = 2;
    }
    
    [self fetchDataWith:urlString intValue:page];
    int totalpage=(int)[total integerValue];
    
    if (page > totalpage && jsonDict){
        self.canLoadMore = NO;
    }
    // signal that there won't be any more items to load
    else
        self.canLoadMore = YES;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return parsedItems.count;
    
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = [NSString stringWithFormat:@"%ld,%ld",(long)indexPath.section,(long)indexPath.row];
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if ([[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"mediaUrl"] length] != 0 && indexPath.row == 0){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        UIImageView *imgview = [[UIImageView alloc]
                                initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, HEADERVIEW_HEIGHT)];
        NSString *url=[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"mediaUrl"];
        [imgview sd_setImageWithURL:[NSURL URLWithString:url]
                   placeholderImage:[UIImage imageNamed:@"default_placeholder"] options:indexPath.row == 0 ? SDWebImageRefreshCached : 0];
        [imgview setContentMode:UIViewContentModeScaleAspectFill];
        imgview.clipsToBounds = true;
        [cell addSubview:imgview];
        
        CGRect frame = CGRectMake(0, (HEADERVIEW_HEIGHT - 100) / 2, self.view.frame.size.width, 100);
        UIView *blueLayer = [[UIView alloc] initWithFrame: frame];
        CAGradientLayer *gradient = [CAGradientLayer layer];
        gradient.frame            = frame;
        gradient.colors           = [NSArray arrayWithObjects:(id)[[UIColor colorWithWhite:0 alpha:0] CGColor],(id)[[UIColor colorWithWhite:0 alpha:0.5] CGColor], nil];
        [blueLayer.layer insertSublayer:gradient atIndex:-1];
        [cell addSubview:blueLayer];
        
        KILabel *lbl1 = [[KILabel alloc] initWithFrame: CGRectMake(10, HEADERVIEW_HEIGHT - 75, self.view.frame.size.width - 20, 65)];
        
        //lbl1.backgroundColor=[UIColor redColor];
        lbl1.font = [UIFont boldSystemFontOfSize: 17];
        lbl1.textColor=[UIColor whiteColor];
        [lbl1 setUserInteractionEnabled:NO];
        [lbl1 setAllignBottom: true];
        lbl1.numberOfLines = 0;
        lbl1.text= [[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"title"] stringByDecodingHTMLEntities];
        
        [cell addSubview:lbl1];
        
    } else {
        
        // static NSString *CellIdentifier = @"Cell";
        UILabel *lbltitle;
        UILabel *lblsummary;
        UIImageView *imageView;
        UILabel *lbldate;
        
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            //	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            
            lbltitle=[[UILabel alloc]init];
            [cell addSubview:lbltitle];
            lbltitle.numberOfLines=0;
            
            lblsummary=[[UILabel alloc]init];
            [cell addSubview:lblsummary];
            lblsummary.numberOfLines=2;
            
            lbldate=[[UILabel alloc]init];
            [cell addSubview:lbldate];
            
            imageView=[[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 80, 80)];
            [cell addSubview:imageView];
            
            [lblsummary setBackgroundColor:[UIColor clearColor]];
            [lbltitle  setBackgroundColor:[UIColor clearColor]];
            [imageView setBackgroundColor:[UIColor clearColor]];
            
            lbltitle.font = [UIFont boldSystemFontOfSize:15];
            lblsummary.font = [UIFont boldSystemFontOfSize:13];
            lbldate.font = [UIFont boldSystemFontOfSize:12];
            
            lblsummary.alpha=0.7;
            lbldate.alpha=0.5;
            
        }
        
        // Configure the cell.
        
        // Process
        NSString *title=[[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"title"] stringByDecodingHTMLEntities];
        NSString *summary=[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"excerpt"];
        NSString *date=[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"date"];
        
        //  NSString *itemSummary = item.summary ? [item.summary stringByConvertingHTMLToPlainText] : @"[No Summary]";
        
        NSInteger widthWithPadding = self.view.frame.size.width - 20;
        
        // Set
        lbltitle.numberOfLines = 5;
        lbltitle.text = title;
        
        NSInteger width = widthWithPadding - 80;
        NSInteger marginLeft = 100;
        BOOL hasImage = TRUE;
        
        if ([[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"mediaUrl"] length] == 0){
            width = widthWithPadding;
            marginLeft = 10;
            hasImage = FALSE;
        }
        
        CGSize size = [lbltitle sizeThatFits:CGSizeMake(width, CGFLOAT_MAX)];
        
        NSInteger height = size.height;
        if (size.height<90 && hasImage) {
            height = 90;
        }
        
        lbltitle.lineBreakMode = NSLineBreakByTruncatingTail;
        lbltitle.frame=CGRectMake(marginLeft, 3, width, height);
        
        lblsummary.frame=CGRectMake(10, height+5, widthWithPadding, 35);
        lbldate.frame=CGRectMake(10, height+45, widthWithPadding, 10);
        
        NSString *itemSummary =  [summary stringByConvertingHTMLToPlainText] ;
        lblsummary.text=itemSummary;
        
        if (hasImage){
            NSString *url=[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"mediaUrl"];
            [imageView sd_setImageWithURL:[NSURL URLWithString:url]
                         placeholderImage:[UIImage imageNamed:@"default_placeholder"] options:indexPath.row == 0 ? SDWebImageRefreshCached : 0];
            imageView.contentMode = UIViewContentModeScaleAspectFill;
            [imageView setClipsToBounds:YES];
        }
        
        if (date) {
            
            lbldate.text=date;
            
        }
    }
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"mediaUrl"] length] != 0 && indexPath.row == 0){
        
        return HEADERVIEW_HEIGHT;
        
    } else {
        
        NSString *title=[[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"title"] stringByDecodingHTMLEntities];
        
        CGSize maximumLabelSize;
        BOOL hasImage = TRUE;
        
        //CGFloat lineHeight = [title sizeWithFont:[UIFont boldSystemFontOfSize:15]].height;
        
        //TODO do something with max numer of lines?
        NSInteger widthWithPadding = self.view.frame.size.width - 20;
        
        if ([[[parsedItems objectAtIndex:indexPath.row]valueForKey:@"mediaUrl"] length] == 0){
            maximumLabelSize = CGSizeMake(widthWithPadding, MAXFLOAT);
            hasImage = FALSE;
        } else {
            maximumLabelSize = CGSizeMake(widthWithPadding - 80, MAXFLOAT);
        }
        
        NSStringDrawingOptions options = NSStringDrawingTruncatesLastVisibleLine |
        NSStringDrawingUsesLineFragmentOrigin;
        
        NSDictionary *attr = @{NSFontAttributeName: [UIFont boldSystemFontOfSize:15]};
        CGRect labelBounds = [title boundingRectWithSize:maximumLabelSize
                                                 options:options
                                              attributes:attr
                                                 context:nil];
        CGFloat height = ceilf(labelBounds.size.height);
        
        if (height<110 && hasImage) {
            height = 110;
        } else if (!hasImage){
            height = height + 20;
        }
        
        return height+45;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // Show detail
    WordpressDetailViewController *detailView = [[WordpressDetailViewController alloc] initWithNibName:@"WordpressDetailViewController" bundle:nil];
    detailView.titleText = [[parsedItems objectAtIndex:indexPath.row]valueForKey:@"title"];
    detailView.detailID = [[parsedItems objectAtIndex:indexPath.row]valueForKey:@"id"];
    detailView.articleUrl = [[parsedItems objectAtIndex:indexPath.row]valueForKey:@"url"];
    detailView.date = [[parsedItems objectAtIndex:indexPath.row]valueForKey:@"date"];
    detailView.author = [[parsedItems objectAtIndex:indexPath.row]valueForKey:@"author"];
    detailView.imageUrl = [[parsedItems objectAtIndex:indexPath.row]valueForKey:@"mediaUrl"];
    
    //NSArray *attachments= [[parsedItems objectAtIndex:indexPath.row] valueForKey:@"attachments"];
    //TODO implement the new mediaUrl
    //if ([attachments count] > 0 && [NSNull null] != [[attachments objectAtIndex:0] valueForKey:@"url"]){
    //    NSString *attachmenturl= [[attachments objectAtIndex:0] valueForKey:@"url"];
    //    detailView.imageUrl = attachmenturl;
    //}
    
    //NSArray *attachments= [[parsedItems objectAtIndex:indexPath.row] valueForKey:@"attachments"];
    //NSObject *thumbnails= [[parsedItems objectAtIndex:indexPath.row] valueForKey:@"thumbnail_images"];
    //if ([attachments count] > 0 && [NSNull null] != [[attachments objectAtIndex:0] valueForKey:@"url"]){
    //    detailView.imageUrl = [[attachments objectAtIndex:0] valueForKey:@"url"];
    //} else if ([NSNull null] != thumbnails && [thumbnails valueForKey:@"large"] != nil){
    //    detailView.imageUrl = [[thumbnails valueForKey:@"large"] valueForKey:@"url"];
    //}
    
    detailView.mainURL=mainURL;
    
    if (detailView.mainURL.length==0) {
        
        detailView.mainURL=mainURL;
        
    }
    
    [self.navigationController pushViewController:detailView animated:YES];
    
    // Deselect
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)dealloc
{
    if ([self isViewLoaded])
    {
        self.tableView.delegate = nil;
        self.tableView.dataSource = nil;
    }
}

@end
