//
//  RssViewController.m
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//
//  Implements: MWFeedParser
//  Copyright (c) 2010 Michael Waterfall
//

#import "RssViewController.h"
#import "NSString+HTML.h"
#import "MWFeedParser.h"
#import "RssDetailViewController.h"
#import "AssistTableHeaderView.h"
#import "AssistTableFooterView.h"
#import "SWRevealViewController.h"
#import "AppDelegate.h"
#import "CommonBanner.h"

@implementation RssViewController

@synthesize itemsToDisplay,urlString,navTitle;

#pragma mark -
#pragma mark View lifecycle

- (void)viewDidLoad {
    
    // Super
    [super viewDidLoad];
    
    if (ADS_ON)
        self.canDisplayAds = YES;
    
    // Setup
    self.title = @"Loading...";
    
    [self.tableView addGestureRecognizer: self.revealViewController.panGestureRecognizer];
    [self.tableView addGestureRecognizer: self.revealViewController.tapGestureRecognizer];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.tableView.tableFooterView = [[UIView alloc] init];
    btn.frame = CGRectMake(0, 0, 20, 20);
    [btn setImage:[UIImage imageNamed:@"reveal-icon"] forState:UIControlStateNormal];
    [btn addTarget:self.revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftBarButton = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
    self.navigationItem.leftBarButtonItem = leftBarButton;
    formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterShortStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    parsedItems = [[NSMutableArray alloc] init];
    self.itemsToDisplay = [NSArray array];
    
    NSURL *feedURL = [NSURL URLWithString:urlString];
    
    feedParser = [[MWFeedParser alloc] initWithFeedURL:feedURL];
    feedParser.delegate = self;
    feedParser.feedParseType = ParseTypeFull; // Parse feed info and all items
    feedParser.connectionType = ConnectionTypeAsynchronously;
    [feedParser parse];
    
    // set the custom view for "pull to refresh". See AssistTableHeaderView.xib.
    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AssistTableHeaderView" owner:self options:nil];
    AssistTableHeaderView *headerView = (AssistTableHeaderView *)[nib objectAtIndex:0];
    self.headerView = headerView;
    
    // set the custom view for "load more". See AssistTableFooterView.xib.
    nib = [[NSBundle mainBundle] loadNibNamed:@"AssistTableFooterView" owner:self options:nil];
    AssistTableFooterView *footerView = (AssistTableFooterView *)[nib objectAtIndex:0];
    self.footerView = footerView;
    
}

- (void)viewDidLayoutSubviews
{
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)])
        self.edgesForExtendedLayout = UIRectEdgeNone;
}

- (void) pinHeaderView
{
    [super pinHeaderView];
    
    // do custom handling for the header view
    AssistTableHeaderView *hv = (AssistTableHeaderView *)self.headerView;
    [hv.activityIndicator startAnimating];
    hv.title.text = @"Loading...";
}

- (void) unpinHeaderView
{
    [super unpinHeaderView];
    
    // do custom handling for the header view
    [[(AssistTableHeaderView *)self.headerView activityIndicator] stopAnimating];
}

- (void) headerViewDidScroll:(BOOL)willRefreshOnRelease scrollView:(UIScrollView *)scrollView
{
    AssistTableHeaderView *hv = (AssistTableHeaderView *)self.headerView;
    if (willRefreshOnRelease)
        hv.title.text = @"Release to refresh...";
    else
        hv.title.text = @"Pull down to refresh...";
}

// Reset and reparse
- (BOOL)refresh {
    if (![super refresh])
        return NO;
    
    [parsedItems removeAllObjects];
    [feedParser stopParsing];
    [feedParser parse];
    self.tableView.userInteractionEnabled = NO;
    //self.tableView.alpha = 0.3;
    return YES;
}

- (void) willBeginLoadingMore
{
    AssistTableFooterView *fv = (AssistTableFooterView *)self.footerView;
    [fv.activityIndicator startAnimating];
}

- (void) loadMoreCompleted
{
    [super loadMoreCompleted];
    
    AssistTableFooterView *fv = (AssistTableFooterView *)self.footerView;
    [fv.activityIndicator stopAnimating];
    
    if (!self.canLoadMore) {
        // Do something if there are no more items to load
        
        // Just show a textual info that there are no more items to load
        fv.infoLabel.hidden = YES;
        [self setFooterViewVisibility:FALSE];
    }
}

- (void)updateTableWithParsedItems {
    self.itemsToDisplay = parsedItems ;//sortedArrayUsingDescriptors: [NSArray arrayWithObject:[[NSSortDescriptor alloc] initWithKey:@"date" ascending:NO]]];
    self.tableView.userInteractionEnabled = YES;
    //self.tableView.alpha = 1;
    self.canLoadMore = NO;
    [self refreshCompleted];
    [self loadMoreCompleted];
    [self.tableView reloadData];
}

#pragma mark -
#pragma mark MWFeedParserDelegate

- (void)feedParserDidStart:(MWFeedParser *)parser {
    //NSLog(@"Started Parsing: %@", parser.url);
}

- (void)feedParser:(MWFeedParser *)parser didParseFeedInfo:(MWFeedInfo *)info {
    // NSLog(@"Parsed Feed Info: “%@”", info.title);
    //self.title = info.title; //if you want the title to be the feed title unquote
    self.title = navTitle;
}

- (void)feedParser:(MWFeedParser *)parser didParseFeedItem:(MWFeedItem *)item {
   // NSLog(@"Parsed Feed Item: “%@”", item.title);
    if (item) [parsedItems addObject:item];
}

- (void)feedParserDidFinish:(MWFeedParser *)parser {
   // NSLog(@"Finished Parsing%@", (parser.stopped ? @" (Stopped)" : @""));
    [self updateTableWithParsedItems];
}

- (void)feedParser:(MWFeedParser *)parser didFailWithError:(NSError *)error {
    NSLog(@"Finished Parsing With Error: %@", error);
    if (parsedItems.count == 0) {
        self.title = @"Failed"; // Show failed message in title
        
        [[[UIAlertView alloc]initWithTitle:@"Error" message:NO_CONNECTION_TEXT delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
        
        [self refreshCompleted];
        [self loadMoreCompleted];
        
    } else {
        // Failed but some items parsed, so show and inform of error
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Parsing Incomplete"
                                                        message:@"There was an error during the parsing of this feed. Not all of the feed items could parsed."
                                                       delegate:nil
                                              cancelButtonTitle:@"Dismiss"
                                              otherButtonTitles:nil];
        [alert show];
        
        [self updateTableWithParsedItems];
    }
    //[self updateTableWithParsedItems];
}

#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return itemsToDisplay.count;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *CellIdentifier = [NSString stringWithFormat:@"%ld,%ld",(long)indexPath.section,(long)indexPath.row];
    // static NSString *CellIdentifier = @"Cell";
    UILabel *lbltitle;
    UILabel *lblsummary;
    UIImageView *imageView;
    UILabel *lbldate;
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        //	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        lbltitle=[[UILabel alloc]init];
        [cell addSubview:lbltitle];
        lbltitle.numberOfLines=0;
        
        lblsummary=[[UILabel alloc]init];
        [cell addSubview:lblsummary];
        lblsummary.numberOfLines=2;
        
        lbldate=[[UILabel alloc]init];
        [cell addSubview:lbldate];
 
        [lblsummary setBackgroundColor:[UIColor clearColor]];
        [lbltitle  setBackgroundColor:[UIColor clearColor]];
        [imageView setBackgroundColor:[UIColor clearColor]];
        
        lbltitle.font = [UIFont boldSystemFontOfSize:15];
        lblsummary.font = [UIFont boldSystemFontOfSize:13];
        lbldate.font = [UIFont boldSystemFontOfSize:12];
        
        lblsummary.alpha=0.7;
        lbldate.alpha=0.5;
        
    }
    
    // Configure the cell.
    MWFeedItem *item = [itemsToDisplay objectAtIndex:indexPath.row];
    if (item) {
        
        // Process
        NSString *itemTitle = item.title ? [item.title stringByConvertingHTMLToPlainText] : @"[No Title]";
        NSString *itemSummary = item.summary ? [item.summary stringByConvertingHTMLToPlainText] : @"[No Summary]";
        // Set
        
        if (item.media){
            imageView=[[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 80, 60)];
            imageView.contentMode = UIViewContentModeScaleAspectFit;
            [cell addSubview:imageView];
            
            [imageView sd_setImageWithURL:[NSURL URLWithString:item.media]
                     placeholderImage:[UIImage imageNamed:@"placeholder"] options:indexPath.row == 0 ? SDWebImageRefreshCached : 0];
        }
        
        NSInteger widthWithPadding = self.view.frame.size.width - 20;
        
        CGSize maximumLabelSize;
        if (item.media) {
            maximumLabelSize = CGSizeMake(widthWithPadding - 80, MAXFLOAT);
        } else {
            maximumLabelSize = CGSizeMake(widthWithPadding, MAXFLOAT);
        }
        
        NSStringDrawingOptions options = NSStringDrawingTruncatesLastVisibleLine |
        NSStringDrawingUsesLineFragmentOrigin;
        
        NSDictionary *attr = @{NSFontAttributeName: [UIFont boldSystemFontOfSize:15]};
        CGRect labelBounds = [itemTitle boundingRectWithSize:maximumLabelSize
                                                     options:options
                                                  attributes:attr
                                                     context:nil];
        
        CGFloat height = ceilf(labelBounds.size.height);

        if (item.media){
            if (height<70) {
                height = 70;
            }
            
            lbltitle.frame=CGRectMake(100, 5, widthWithPadding - 80, height);
        } else {
            lbltitle.frame=CGRectMake(10, 5, widthWithPadding, height);
        }
        
        lblsummary.frame=CGRectMake(10, height+5, widthWithPadding, 35);
        lbldate.frame=CGRectMake(10, height+45, widthWithPadding, 10);
        
        lbltitle.text = itemTitle;
        lblsummary.text = itemSummary;
        
        if (item.date) {
            
            NSString *date=[NSString stringWithFormat:@"%@",item.date];
            lbldate.text=date;
            
        }
        
    }
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MWFeedItem *item = [itemsToDisplay objectAtIndex:indexPath.row];
    NSString *itemTitle = [item.title stringByConvertingHTMLToPlainText];
    //getting expected height of the text
    
    NSInteger widthWithPadding = self.view.frame.size.width - 20;

    CGSize maximumLabelSize;
    if (item.media) {
            maximumLabelSize = CGSizeMake(widthWithPadding - 80, MAXFLOAT);
    } else {
            maximumLabelSize = CGSizeMake(widthWithPadding, MAXFLOAT);
    }
    
    NSStringDrawingOptions options = NSStringDrawingTruncatesLastVisibleLine |
    NSStringDrawingUsesLineFragmentOrigin;
    
    NSDictionary *attr = @{NSFontAttributeName: [UIFont boldSystemFontOfSize:15]};
    CGRect labelBounds = [itemTitle boundingRectWithSize:maximumLabelSize
                                                 options:options
                                              attributes:attr
                                                 context:nil];
    CGFloat height = ceilf(labelBounds.size.height);
        
    if (height<80 && item.media) {
        return 140;
    }
    return height+70;
}
#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // Show detail
    RssDetailViewController *detail = [[RssDetailViewController alloc] initWithNibName:@"RssDetailViewController" bundle:nil];
    
    detail.item = (MWFeedItem *)[itemsToDisplay objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:detail animated:YES];
    
    // Deselect
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

#pragma mark -
#pragma mark Memory management


@end
