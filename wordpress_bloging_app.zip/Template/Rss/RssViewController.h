//
//  RssViewController.h
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//
//  Implements: MWFeedParser
//  Copyright (c) 2010 Michael Waterfall
//

#import <UIKit/UIKit.h>
#import "MWFeedParser.h"
#import "UIImageView+WebCache.h"
#import "STableViewController.h"

@interface RssViewController : STableViewController <MWFeedParserDelegate> {
	
	// Parsing
	MWFeedParser *feedParser;
	NSMutableArray *parsedItems;
	
	// Displaying
	NSArray *itemsToDisplay;
	NSDateFormatter *formatter;
	
}

// Properties
@property (nonatomic, strong) NSArray *itemsToDisplay;
@property(strong,nonatomic)NSString *urlString;
@property(strong,nonatomic)NSString *navTitle;

@end
