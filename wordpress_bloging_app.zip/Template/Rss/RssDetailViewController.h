//
//  RssDetailViewController.h
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailViewAssistant.h"
#import "ActionCell.h"
#import "TitleCell.h"
#import "ShowPageCell.h"
#import "MWFeedItem.h"

@interface RssDetailViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,UIWebViewDelegate,DetailViewAssistantDelegate>{
    ShowPageCell *showPageCell;
    NSMutableArray *parsedItems;
}

@property (nonatomic, strong) DetailViewAssistant *articleDetail;

@property (strong, nonatomic) UIWebView *webViewDisplay;
@property (nonatomic, retain) NSString *wrappedText;
@property (nonatomic, retain) NSString *titleText;
@property (nonatomic, retain) UIFont *textFont;

//old
@property (strong,nonatomic) NSString *imageUrl;
@property (strong,nonatomic) NSString *date;
@property (strong,nonatomic) NSString *html;

@property (nonatomic, strong) MWFeedItem *item;

@property (weak, nonatomic) IBOutlet UIView *headerView;
@property (weak, nonatomic) IBOutlet UILabel *headerTitle;
@end
