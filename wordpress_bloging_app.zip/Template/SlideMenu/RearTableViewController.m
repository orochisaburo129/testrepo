//
//  RearTableViewController.m
//
//  Copyright (c) 2015 Sherdle. All rights reserved.
//

#import "RearTableViewController.h"
#import "SWRevealViewController.h"
#import "KILabel.h"

#import "RadioViewController.h"
#import "FacebookViewController.h"
#import "MapsViewController.h"
#import "RssViewController.h"
#import "YoutubeViewController.h"
#import "TumblrViewController.h"
#import "WebViewController.h"
#import "WordpressViewController.h"
#import "InstagramViewController.h"
#import "TwitterViewController.h"

#import "Config.h"

#import "AppDelegate.h"

#define SELECTED_COLOR [UIColor colorWithRed:0.0f/255.0f green:66.0f/255.0f blue:117.0f/255.0f alpha:0.2]

@interface RearTableViewController ()

@end

@implementation RearTableViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.navigationController setNavigationBarHidden:YES];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = [UIColor clearColor];
    
    Config * obje = [[Config  alloc]init];
    
    self.selectedIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    
    self.sectionArray = [obje config];
    
    if (![ABOUT_TEXT isEqual: @""]){
    
        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
        [button setTitle:@"About" forState:UIControlStateNormal];
        [button setTitleColor: [UIColor whiteColor] forState:UIControlStateNormal];
        [button sizeToFit];
        button.center = CGPointMake(-10, 0);
        [button addTarget:self
                      action:@selector(launchAbout:)
            forControlEvents:UIControlEventTouchDown];
        self.tableView.tableFooterView = button;
    }
}

- (void) launchAbout:(UIButton *)paramSender{
    [[[UIAlertView alloc]initWithTitle:@"About"
                                message:ABOUT_TEXT delegate:self
                                cancelButtonTitle:@"Ok"
                                otherButtonTitles:@"Support", nil]show];
}

- (void)alertView:(UIAlertView *)alertView
clickedButtonAtIndex:(NSInteger)buttonIndex{
     if (buttonIndex == [alertView firstOtherButtonIndex]){
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:ABOUT_URL]];
     }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}

-(void)myItemsClicked{
    
}

-(void)settingBtnClicked {
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    //NSLog(@"The number is: %lu", (unsigned long)self.sectionArray.count);
    return self.sectionArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    NSMutableArray *sec = [self.sectionArray objectAtIndex: section];
    
    return (sec.count - 1);
}


// item view
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = [NSString stringWithFormat:@"CellForRow%ldSection%ld",(long)indexPath.row, (long)indexPath.section];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        
        [cell.contentView addSubview:lblHorizLineBottom];
        
        cellImgVw = [[UIImageView alloc]initWithFrame:CGRectMake(220, 10, 24, 24)];
        
        //TODO no need to transform every image if we can use a white png
        cellImgVw.image = [self overlayImage:[UIImage imageNamed:@"forward-512.png"] withColor:[UIColor whiteColor]];
        
        cellImgVw.alpha = 0.5;
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.textLabel.font = [UIFont fontWithName:@"HelveticaNeue-Light" size:16];
        
        [cell.contentView addSubview:cellImgVw];
        
        UIView *bgColorView = [[UIView alloc] init];
        bgColorView.backgroundColor = SELECTED_COLOR;
        [cell setSelectedBackgroundView:bgColorView];
        
        
    }
    
    NSArray *item = [[self.sectionArray objectAtIndex: indexPath.section] objectAtIndex:(indexPath.row+1)];
    
    cell.textLabel.text= [item objectAtIndex: 0];
    
    if ([item count] > 4 && [item objectAtIndex: 4] != nil){
        cell.imageView.image = [UIImage imageNamed:[item objectAtIndex: 4]];
    }
    
    if ([indexPath isEqual: self.selectedIndexPath]){
        cell.backgroundColor = SELECTED_COLOR;
    } else {
        cell.backgroundColor = [UIColor clearColor];
    }
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}

//table head view
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    _headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    
    UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(15, 0, 300, 40)];
    
    lbl.backgroundColor = [UIColor clearColor];
    lbl.font = [UIFont systemFontOfSize:18];
    lbl.textColor = [UIColor lightTextColor];
    
    NSMutableArray *sec = [self.sectionArray objectAtIndex: section];

    lbl.text = [sec objectAtIndex:0];
    
    //UILabel *lblLine = [[UILabel alloc]initWithFrame:CGRectMake(5, 10, 310, 30)];
    
    //lblLine.backgroundColor = [UIColor clearColor];
    
    //lblLine.font = [UIFont systemFontOfSize:20];
    
    //lblLine.textColor = [UIColor colorWithRed:23.0f/255 green:119.0f/255 blue:118.0f/255 alpha:1];
    
    //[_headerView addSubview:lblLine];
    
    [_headerView addSubview:lbl];
    
    return _headerView;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if ([[[self.sectionArray objectAtIndex: section] objectAtIndex:0]  isEqual: @""])
        return CGFLOAT_MIN;
    return 35;
}

//clicklistener
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    UITableViewCell *oldselectedcell = [tableView cellForRowAtIndexPath:self.selectedIndexPath];
    oldselectedcell.backgroundColor = [UIColor clearColor];
    
    self.selectedIndexPath = indexPath;
    UITableViewCell *currentcell = [tableView cellForRowAtIndexPath:indexPath];
    currentcell.backgroundColor = SELECTED_COLOR;
    
    [self.revealViewController revealToggle:nil];
    
    NSArray *item = [[self.sectionArray objectAtIndex: indexPath.section] objectAtIndex:(indexPath.row + 1)];
    
    NSLog(@"section: %li row: %li",(long)indexPath.section, (long)indexPath.row);
    
    [self selectItem: item];
        }

-(UIViewController *) selectItem:(NSArray*) item {
    NSString *SOCIAL_ITEMS_NAME = [item objectAtIndex: 0];
    NSString *SOCIAL_ITEMS_TYPE = [item objectAtIndex: 1];
    NSString *SOCIAL_ITEMS_URL = [item objectAtIndex: 2];
    NSString *SOCIAL_API = [item objectAtIndex: 3];

    UINavigationController *nav;
    UIViewController *viewControl;
    
    if ([SOCIAL_ITEMS_TYPE isEqualToString:@"TWITTER"]) {
        
        TwitterViewController *twitter=[[TwitterViewController alloc]init];
        
        twitter.screenName = SOCIAL_ITEMS_URL;
        twitter.navTitle = SOCIAL_ITEMS_NAME;
        
        viewControl = twitter;
        
    } else if ([SOCIAL_ITEMS_TYPE isEqualToString:@"WORDPRESS"]) {
        
        WordpressViewController *wordpress=[[WordpressViewController alloc]initWithNibName:nil bundle:nil];
        
        wordpress.urlString=SOCIAL_ITEMS_URL;
        wordpress.mainURL=SOCIAL_API;
        wordpress.navTitle=SOCIAL_ITEMS_NAME;
        
        viewControl = wordpress;
        
    } else if ([SOCIAL_ITEMS_TYPE isEqualToString:@"YOUTUBE"]){
        YoutubeViewController *youTube=[[YoutubeViewController alloc]initWithNibName:nil bundle:nil];
        
        youTube.urlString = SOCIAL_ITEMS_URL;
        youTube.navTitle = SOCIAL_ITEMS_NAME;
        
        viewControl = youTube;
        
    } else if ([SOCIAL_ITEMS_TYPE isEqualToString:@"TUMBLR"]) {
        TumblrViewController *tumblr = [[TumblrViewController alloc]initWithNibName:@"TumblrViewController" bundle:nil];
        
        tumblr.urlString = SOCIAL_ITEMS_URL;
        tumblr.navTitle = SOCIAL_ITEMS_NAME;
        
        viewControl = tumblr;
        
    } else if ([SOCIAL_ITEMS_TYPE isEqualToString:@"MAPS"]) {
        MapsViewController *mapView;
        mapView=[[MapsViewController alloc]initWithNibName:nil bundle:nil];
        
        mapView.urlString= [item objectAtIndex: 2];
        mapView.mainURL= [item objectAtIndex: 3];
        mapView.navTitle=SOCIAL_ITEMS_NAME;
        
        viewControl = mapView;
        
    } else if ([SOCIAL_ITEMS_TYPE isEqualToString:@"RADIO"]) {
        RadioViewController *radio = [[RadioViewController alloc]initWithNibName:@"RadioViewController" bundle:nil];
        
        radio.urlString = SOCIAL_ITEMS_URL;
        radio.navTitle = SOCIAL_ITEMS_NAME;
        
        viewControl = radio;
        
    } else if ([SOCIAL_ITEMS_TYPE isEqualToString:@"WEB"]) {
        WebViewController *webView=[[WebViewController alloc]initWithNibName:nil bundle:nil];
        
        webView.urlString = SOCIAL_ITEMS_URL;
        webView.navTitle = SOCIAL_ITEMS_NAME;
        
        viewControl = webView;
    }  else if ([SOCIAL_ITEMS_TYPE isEqualToString:@"RSS"]) {
        RssViewController *rss=[[RssViewController alloc]initWithNibName:nil bundle:nil];
        
        rss.urlString = SOCIAL_ITEMS_URL;
        rss.navTitle = SOCIAL_ITEMS_NAME;
        
        viewControl = rss;
    }  else if ([SOCIAL_ITEMS_TYPE isEqualToString:@"FACEBOOK"]) {
        FacebookViewController *fb=[[FacebookViewController alloc]initWithNibName:nil bundle:nil];
        
        fb.urlString = SOCIAL_ITEMS_URL;
        fb.navTitle = SOCIAL_ITEMS_NAME;
        
        viewControl = fb;
    }  else if ([SOCIAL_ITEMS_TYPE isEqualToString:@"INSTAGRAM"]) {
        InstagramViewController *instagram=[[InstagramViewController alloc]initWithNibName:nil bundle:nil];

        instagram.urlString = SOCIAL_ITEMS_URL;
        instagram.navTitle = SOCIAL_ITEMS_NAME;
        
        viewControl = instagram;
    }

    
    nav=[[UINavigationController alloc]initWithRootViewController:viewControl];
    [self.revealViewController setFrontViewController:nav];
    
    return viewControl;

}

- (UIImage *)overlayImage:(UIImage *)image withColor:(UIColor *)color
{
    //  Create rect to fit the PNG image
    CGRect rect = CGRectMake(0, 0, image.size.width, image.size.height);
    
    //  Start drawing
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSaveGState(context);
    
    //  Fill the rect by the final color
    [color setFill];
    CGContextFillRect(context, rect);
    
    //  Make the final shape by masking the drawn color with the images alpha values
    CGContextSetBlendMode(context, kCGBlendModeDestinationIn);
    [image drawInRect: rect blendMode:kCGBlendModeDestinationIn alpha:1];
    
    //  Create new image from the context
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    
    //  Release context
    UIGraphicsEndImageContext();
    
    return img;
}

@end
